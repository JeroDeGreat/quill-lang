from setuptools import setup, find_packages

setup(
    name='quill-lang',
    version='1.0.0',
    description='Quill — Write code the way you think.',
    long_description=open('README.md').read(),
    long_description_content_type='text/markdown',
    author='Quill Language Team',
    url='https://quill-lang.org',
    packages=find_packages(),
    python_requires='>=3.10',
    entry_points={
        'console_scripts': [
            'quill=quill.__main__:main',
        ],
    },
    classifiers=[
        'Programming Language :: Other',
        'License :: OSI Approved :: MIT License',
        'Operating System :: OS Independent',
    ],
)
