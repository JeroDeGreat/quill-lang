const vscode = require('vscode');
const path = require('path');
const { exec } = require('child_process');

function activate(context) {
    console.log('Quill Language Support activated');

    // ── Helper: get clean quill executable path ───────────────────────
    // Always strips surrounding quotes the user might have typed in settings,
    // so we can safely re-wrap in quotes ourselves when building shell commands.
    function getQuillPath() {
        const config = vscode.workspace.getConfiguration('quill');
        const raw = config.get('executablePath', 'quill');
        return raw.replace(/^["']+|["']+$/g, '').trim();
    }

    // ── Command: Run Quill File ──────────────────────────────────────
    // Opens a terminal and runs:  "quill.bat" run "file.ql"
    // Using sendText() into a real terminal means Windows handles all
    // the quoting/PATH issues — no exec() involved.
    const runCmd = vscode.commands.registerCommand('quill.runFile', () => {
        const editor = vscode.window.activeTextEditor;
        if (!editor) {
            vscode.window.showErrorMessage('Quill: No file is open.');
            return;
        }
        if (!editor.document.fileName.endsWith('.ql')) {
            vscode.window.showErrorMessage('Quill: This only works on .ql files.');
            return;
        }

        editor.document.save().then(() => {
            const quillPath = getQuillPath();
            const filePath  = editor.document.fileName;

            const terminal = vscode.window.createTerminal({
                name: `Quill ▶ ${path.basename(filePath)}`,
                cwd:  path.dirname(filePath)
            });
            terminal.show(true);

            // Wrap both paths in quotes to handle spaces in usernames / directories.
            // sendText goes straight into the shell so this is the right place to quote.
            terminal.sendText(`& "${quillPath}" run "${filePath}"`);
        });
    });

    // ── Command: Check Syntax ────────────────────────────────────────
    // Manual check triggered by the user — shows a popup result.
    // Only runs when the user explicitly asks, never automatically.
    const checkCmd = vscode.commands.registerCommand('quill.checkFile', () => {
        const editor = vscode.window.activeTextEditor;
        if (!editor) return;

        const quillPath = getQuillPath();
        const filePath  = editor.document.fileName;

        // Use the same terminal approach as run — avoids exec() quoting issues
        const terminal = vscode.window.createTerminal({
            name: `Quill Check`,
            cwd:  path.dirname(filePath)
        });
        terminal.show(true);
        terminal.sendText(`& "${quillPath}" check "${filePath}"`);
    });

    // ── Hover provider ────────────────────────────────────────────────
    // Shows documentation when you hover over a Quill keyword.
    // Pure JS — no process spawning, completely safe.
    const hoverProvider = vscode.languages.registerHoverProvider('quill', {
        provideHover(document, position) {
            const wordRange = document.getWordRangeAtPosition(
                position, /[a-zA-Z][a-zA-Z0-9 _-]*/
            );
            if (!wordRange) return undefined;
            const word = document.getText(wordRange).toLowerCase().trim();
            const doc  = KEYWORD_DOCS[word];
            if (doc) {
                return new vscode.Hover(new vscode.MarkdownString(doc));
            }
            return undefined;
        }
    });

    // ── Completion provider ───────────────────────────────────────────
    // Keyword + snippet completions.
    // Pure JS — no process spawning, completely safe.
    const completionProvider = vscode.languages.registerCompletionItemProvider(
        'quill',
        {
            provideCompletionItems(document, position) {
                const items = [];

                for (const [label, snippet, detail] of KEYWORD_COMPLETIONS) {
                    const item = new vscode.CompletionItem(
                        label,
                        vscode.CompletionItemKind.Keyword
                    );
                    item.insertText = new vscode.SnippetString(snippet);
                    item.detail     = detail;
                    items.push(item);
                }

                // Module names after "use "
                const linePrefix = document
                    .lineAt(position)
                    .text.substring(0, position.character);
                if (/\buse\s+$/i.test(linePrefix)) {
                    for (const mod of STDLIB_MODULES) {
                        const item = new vscode.CompletionItem(
                            mod,
                            vscode.CompletionItemKind.Module
                        );
                        item.insertText = `${mod}.`;
                        item.detail     = `Quill standard library module`;
                        items.push(item);
                    }
                }

                return items;
            }
        },
        ' '
    );

    context.subscriptions.push(runCmd, checkCmd, hoverProvider, completionProvider);
}

function deactivate() {}

// ── Static data ───────────────────────────────────────────────────────────

const STDLIB_MODULES = [
    'math', 'files', 'web', 'time', 'random', 'os', 'json', 'gui', 'database', 'crypto'
];

const KEYWORD_COMPLETIONS = [
    ['let',        'let ${1:name} be ${2:value}.',                    'Declare a variable'],
    ['set',        'set ${1:name} to ${2:value}.',                    'Reassign a variable'],
    ['say',        'say "${1:Hello!}".',                              'Print to output'],
    ['print',      'print "${1:Hello!}".',                            'Print to output'],
    ['ask',        'ask "${1:What is your name?}" into ${2:name}.',   'Read user input'],
    ['if',
`if \${1:condition}.
  \${2:say "Hello.".}
end if.`,                                                             'If statement'],
    ['if else',
`if \${1:condition}.
  \${2:say "Yes.".}
else.
  \${3:say "No.".}
end if.`,                                                             'If / else statement'],
    ['repeat',
`repeat \${1:5} times.
  \${2:say "Hello!".}
end repeat.`,                                                         'Repeat N times'],
    ['repeat from',
`repeat from \${1:1} to \${2:10}.
  say the current count.
end repeat.`,                                                         'Repeat over a range'],
    ['while',
`while \${1:condition}.
  \${2:say "Still going.".}
end while.`,                                                          'While loop'],
    ['for each',
`for each \${1:item} in \${2:items}.
  say \${1:item}.
end for.`,                                                            'For each loop'],
    ['define',
`define \${1:myFunction} taking \${2:argument}.
  \${3:return argument.}
end define.`,                                                         'Define a function'],
    ['define no args',
`define \${1:myFunction}.
  \${2:say "Hello.".}
end define.`,                                                         'Define a function (no arguments)'],
    ['return',     'return ${1:value}.',                              'Return a value'],
    ['try',
`try.
  \${1:say "Trying.".}
catch error.
  say "Something went wrong: {error}".
end try.`,                                                            'Try / catch error handling'],
    ['raise',      'raise error "${1:Something went wrong}."',       'Raise an error'],
    ['use',        'use ${1|math,files,web,time,random,os,json,gui|}.',  'Import a module'],
    ['note',       'note ${1:This is a comment.}',                   'Single-line comment'],
    ['begin note',
`begin note.
  \${1:Multi-line comment.}
end note.`,                                                           'Multi-line comment'],
    ['let list',   'let ${1:items} be a list of ${2:"one"}, ${3:"two"}.', 'Create a list'],
    ['let map',    'let ${1:data} be a map with ${2:"key"} as ${3:"value"}.', 'Create a map'],
    ['add to',     'add ${1:value} to ${2:variable}.',               'Add to a variable or list'],
    ['subtract',   'subtract ${1:value} from ${2:variable}.',        'Subtract from a variable'],
    ['multiply',   'multiply ${1:variable} by ${2:value}.',          'Multiply a variable'],
    ['divide',     'divide ${1:variable} by ${2:value}.',            'Divide a variable'],
    ['remove',     'remove ${1:value} from ${2:list}.',              'Remove from a list'],
    ['write',      'write ${1:content} to file "${2:output.txt}".',  'Write to a file'],
    ['append',     'append ${1:content} to file "${2:output.txt}".', 'Append to a file'],
    ['stop',       'stop.',                                           'Break out of a loop'],
    ['skip',       'skip.',                                           'Skip to next loop iteration'],
    ['define class',
`define class \${1:MyClass}.
  it has \${2:name}.

  define create taking \${2:name}.
    set its \${2:name} to \${2:name}.
  end define.

  define describe.
    say "{its \${2:name}}".
  end define.
end class.`,                                                          'Define a class'],
];

const KEYWORD_DOCS = {
    'let':     '**`let`** — Declare a new variable.\n\n```\nlet name be "Alice".\nlet age be 25.\nlet items be a list of 1, 2, 3.\n```',
    'set':     '**`set`** — Reassign an existing variable.\n\n```\nset age to 30.\nset name to "Bob".\n```',
    'say':     '**`say`** — Print a value to the console.\n\n```\nsay "Hello!".\nsay "You are {age} years old.".\n```',
    'print':   '**`print`** — Alias for `say`.',
    'display': '**`display`** — Alias for `say`.',
    'ask':     '**`ask`** — Read input from the user.\n\n```\nask "What is your name?" into name.\nask "Enter a number:" into x as number.\n```',
    'if':      '**`if`** — Conditional statement.\n\n```\nif age is greater than 17.\n  say "Adult.".\nelse.\n  say "Minor.".\nend if.\n```',
    'else':    '**`else`** — The fallback branch of an `if` statement.',
    'repeat':  '**`repeat`** — Loop a number of times or over a range.\n\n```\nrepeat 5 times.\n  say "Hi!".\nend repeat.\n\nrepeat from 1 to 10.\n  say the current count.\nend repeat.\n```',
    'while':   '**`while`** — Loop while a condition is true.\n\n```\nwhile score is less than 100.\n  add 10 to score.\nend while.\n```',
    'for':     '**`for each`** — Loop over every item in a list.\n\n```\nfor each fruit in fruits.\n  say fruit.\nend for.\n```',
    'define':  '**`define`** — Define a reusable function.\n\n```\ndefine greet taking name.\n  say "Hello, {name}!".\nend define.\n\ngreet with "Alice".\n```',
    'return':  '**`return`** — Return a value from a function.\n\n```\ndefine double taking n.\n  return n times 2.\nend define.\n```',
    'try':     '**`try`** — Catch and handle errors.\n\n```\ntry.\n  raise error "Oops.".\ncatch err.\n  say "Caught: {err}".\nend try.\n```',
    'raise':   '**`raise`** — Throw an error.\n\n```\nraise error "Value cannot be negative.".\n```',
    'use':     '**`use`** — Import a standard library module.\n\n```\nuse math.\nuse files.\nuse web.\nuse gui.\n```',
    'stop':    '**`stop`** — Break out of a loop immediately (like `break` in other languages).',
    'skip':    '**`skip`** — Skip to the next loop iteration (like `continue` in other languages).',
    'note':    '**`note`** — A comment. Ignored by Quill.\n\n```\nnote This is a comment.\n```',
    'and':     '**`and`** — Logical AND.\n\n```\nif x is greater than 0 and x is less than 10.\n```',
    'or':      '**`or`** — Logical OR.\n\n```\nif name is "Alice" or name is "Bob".\n```',
    'not':     '**`not`** — Logical NOT.\n\n```\nif not active.\n  say "Inactive.".\nend if.\n```',
    'plus':    '**`plus`** — Addition.\n\n```\nlet total be price plus tax.\n```',
    'minus':   '**`minus`** — Subtraction.\n\n```\nlet change be paid minus price.\n```',
    'times':   '**`times`** — Multiplication.\n\n```\nlet area be width times height.\n```',
    'divided': '**`divided by`** — Division.\n\n```\nlet half be total divided by 2.\n```',
    'mod':     '**`mod`** — Remainder after division.\n\n```\nlet remainder be 10 mod 3.\n```',
    'yes':     '**`yes`** — Boolean true.',
    'no':      '**`no`** — Boolean false.',
    'nothing': '**`nothing`** — Null / empty value.\n\n```\nlet x be nothing.\nif x is nothing.\n  say "Empty.".\nend if.\n```',
    'is':      '**`is`** — Equality check, or part of a comparison.\n\n```\nif age is 18.\nif age is greater than 17.\nif name is not "Bob".\n```',
    'math':    '**`math` module** — `use math.`\n\nProvides: `pi`, `e`, square roots, trig, logarithms.',
    'files':   '**`files` module** — `use files.`\n\nProvides: read, write, append, delete, exists.',
    'web':     '**`web` module** — `use web.`\n\nProvides: fetch URL, post to URL, parse JSON.',
    'gui':     '**`gui` module** — `use gui.`\n\nProvides: windows, buttons, labels, text inputs, layouts.',
    'random':  '**`random` module** — `use random.`\n\nProvides: random numbers, random items from lists, shuffle.',
    'time':    '**`time` module** — `use time.`\n\nProvides: current time, current date, wait N seconds.',
    'os':      '**`os` module** — `use os.`\n\nProvides: run shell commands, environment variables.',
    'json':    '**`json` module** — `use json.`\n\nProvides: parse JSON text, create JSON from a map.',
};

module.exports = { activate, deactivate };
