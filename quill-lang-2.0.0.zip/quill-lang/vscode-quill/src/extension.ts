import * as vscode from 'vscode';
import * as cp from 'child_process';
import * as path from 'path';
import * as fs from 'fs';

let diagnosticCollection: vscode.DiagnosticCollection;

export function activate(context: vscode.ExtensionContext) {
    console.log('Quill Language Support is now active!');

    diagnosticCollection = vscode.languages.createDiagnosticCollection('quill');
    context.subscriptions.push(diagnosticCollection);

    // ── Run Quill File ──────────────────────────────────────────────────────
    const runCommand = vscode.commands.registerCommand('quill.runFile', () => {
        const editor = vscode.window.activeTextEditor;
        if (!editor) {
            vscode.window.showErrorMessage('No active Quill file to run.');
            return;
        }
        if (editor.document.isDirty) {
            editor.document.save();
        }
        const filePath = editor.document.fileName;
        const terminal = vscode.window.createTerminal({
            name: `Quill: ${path.basename(filePath)}`,
            cwd: path.dirname(filePath)
        });
        const quillPath = getQuillPath();
        terminal.show(true);
        terminal.sendText(`${quillPath} run "${filePath}"`);
    });

    // ── Check Syntax ────────────────────────────────────────────────────────
    const checkCommand = vscode.commands.registerCommand('quill.checkFile', () => {
        const editor = vscode.window.activeTextEditor;
        if (!editor) return;
        checkSyntax(editor.document);
    });

    // ── Open REPL ───────────────────────────────────────────────────────────
    const replCommand = vscode.commands.registerCommand('quill.openRepl', () => {
        const terminal = vscode.window.createTerminal({ name: 'Quill REPL' });
        const quillPath = getQuillPath();
        terminal.show();
        terminal.sendText(`${quillPath} repl`);
    });

    // ── Lint on save ────────────────────────────────────────────────────────
    const onSave = vscode.workspace.onDidSaveTextDocument(doc => {
        if (doc.languageId === 'quill') {
            const config = vscode.workspace.getConfiguration('quill');
            if (config.get('lintOnSave', true)) {
                checkSyntax(doc);
            }
        }
    });

    // ── Clear diagnostics when file closes ──────────────────────────────────
    const onClose = vscode.workspace.onDidCloseTextDocument(doc => {
        diagnosticCollection.delete(doc.uri);
    });

    // ── Hover provider ──────────────────────────────────────────────────────
    const hoverProvider = vscode.languages.registerHoverProvider('quill', {
        provideHover(document, position) {
            const range = document.getWordRangeAtPosition(position);
            if (!range) return;
            const word = document.getText(range).toLowerCase();
            const info = QUILL_HOVER_INFO[word];
            if (info) {
                const md = new vscode.MarkdownString();
                md.appendCodeblock(info.example, 'quill');
                md.appendMarkdown(`\n\n${info.description}`);
                return new vscode.Hover(md, range);
            }
        }
    });

    // ── Completion provider ─────────────────────────────────────────────────
    const completionProvider = vscode.languages.registerCompletionItemProvider(
        'quill',
        {
            provideCompletionItems(document, position) {
                const items: vscode.CompletionItem[] = [];

                QUILL_KEYWORDS.forEach(kw => {
                    const item = new vscode.CompletionItem(kw, vscode.CompletionItemKind.Keyword);
                    items.push(item);
                });

                QUILL_SNIPPETS_COMPLETIONS.forEach(s => {
                    const item = new vscode.CompletionItem(s.label, vscode.CompletionItemKind.Snippet);
                    item.insertText = new vscode.SnippetString(s.body);
                    item.documentation = s.description;
                    items.push(item);
                });

                // Variable completions from current document
                const text = document.getText();
                const letRegex = /\blet\s+(\w+)\s+be\b/gi;
                let match;
                while ((match = letRegex.exec(text)) !== null) {
                    const varItem = new vscode.CompletionItem(match[1], vscode.CompletionItemKind.Variable);
                    items.push(varItem);
                }

                // Function completions from current document
                const defRegex = /\bdefine\s+(\w+)\b/gi;
                while ((match = defRegex.exec(text)) !== null) {
                    const fnItem = new vscode.CompletionItem(match[1], vscode.CompletionItemKind.Function);
                    items.push(fnItem);
                }

                return items;
            }
        },
        ' ', '\t'
    );

    // ── Status bar item ─────────────────────────────────────────────────────
    const statusBar = vscode.window.createStatusBarItem(vscode.StatusBarAlignment.Right, 100);
    statusBar.text = '$(play) Run Quill';
    statusBar.command = 'quill.runFile';
    statusBar.tooltip = 'Run this Quill file (quill run)';

    const onEditorChange = vscode.window.onDidChangeActiveTextEditor(editor => {
        if (editor && editor.document.languageId === 'quill') {
            statusBar.show();
        } else {
            statusBar.hide();
        }
    });

    if (vscode.window.activeTextEditor?.document.languageId === 'quill') {
        statusBar.show();
    }

    context.subscriptions.push(
        runCommand, checkCommand, replCommand,
        onSave, onClose,
        hoverProvider, completionProvider,
        statusBar, onEditorChange
    );
}

export function deactivate() {
    diagnosticCollection?.dispose();
}

// ── Helpers ───────────────────────────────────────────────────────────────────

function getQuillPath(): string {
    const config = vscode.workspace.getConfiguration('quill');
    return config.get('executablePath', 'quill');
}

function checkSyntax(document: vscode.TextDocument) {
    if (document.languageId !== 'quill') return;
    const quillPath = getQuillPath();
    const filePath = document.fileName;
    diagnosticCollection.delete(document.uri);

    cp.exec(`${quillPath} check "${filePath}"`, (err, stdout, stderr) => {
        if (!err) return;

        const diagnostics: vscode.Diagnostic[] = [];
        const errorText = stderr || stdout;
        const lines = errorText.split('\n');

        for (const line of lines) {
            const match = line.match(/line\s+(\d+):\s*(.+)/i);
            if (match) {
                const lineNum = parseInt(match[1]) - 1;
                const message = match[2];
                const range = new vscode.Range(
                    new vscode.Position(lineNum, 0),
                    new vscode.Position(lineNum, 999)
                );
                const diagnostic = new vscode.Diagnostic(
                    range, message, vscode.DiagnosticSeverity.Error
                );
                diagnostic.source = 'Quill';
                diagnostics.push(diagnostic);
            }
        }

        if (diagnostics.length > 0) {
            diagnosticCollection.set(document.uri, diagnostics);
        }
    });
}

// ── Keyword data ──────────────────────────────────────────────────────────────

const QUILL_KEYWORDS = [
    'let', 'be', 'set', 'to', 'as', 'if', 'else if', 'else', 'end if',
    'repeat', 'repeat from', 'times', 'end repeat', 'while', 'end while',
    'for each', 'end for', 'stop', 'skip', 'return', 'define', 'taking',
    'end define', 'define class', 'end class', 'extending', 'use',
    'try', 'catch', 'end try', 'raise error', 'say', 'print', 'display',
    'ask', 'into', 'fetch', 'write', 'append', 'delete', 'file',
    'the content of file', 'the size of', 'the length of', 'the type of',
    'a list of', 'an empty list', 'a map with', 'a new',
    'plus', 'minus', 'times', 'divided by', 'mod', 'to the power of',
    'square root of', 'and', 'or', 'not', 'is', 'is not',
    'is greater than', 'is less than', 'is at least', 'is at most',
    'is nothing', 'contains', 'starts with', 'ends with', 'split by',
    'in uppercase', 'in lowercase', 'joined with', 'followed by',
    'yes', 'no', 'nothing', 'the current count',
    'open a window', 'create a', 'place', 'show window',
    'when', 'end when', 'is clicked', 'changes', 'closes',
    'note', 'begin note', 'end note',
    'run python', 'run javascript', 'end python', 'end javascript',
    'run in background', 'end run', 'wait until done',
    'call', 'on', 'with', 'with default', 'returns', 'returning',
    'it has', 'its', 'add', 'remove', 'subtract', 'multiply', 'divide',
    'number', 'decimal', 'text', 'truth', 'list', 'map', 'nothing',
    'use math', 'use files', 'use web', 'use time', 'use random',
    'use os', 'use json', 'use gui', 'use database', 'use crypto'
];

const QUILL_SNIPPETS_COMPLETIONS = [
    {
        label: 'if block',
        body: 'if ${1:condition}.\n  ${2:say \"Hello.\".}\nend if.',
        description: 'If block'
    },
    {
        label: 'define function',
        body: 'define ${1:name} taking ${2:arg}.\n  ${3:say arg.}\nend define.',
        description: 'Function definition'
    },
    {
        label: 'repeat times',
        body: 'repeat ${1:5} times.\n  ${2:say \"Hello.\".}\nend repeat.',
        description: 'Repeat N times'
    },
    {
        label: 'for each loop',
        body: 'for each ${1:item} in ${2:list}.\n  say ${1:item}.\nend for.',
        description: 'For each loop'
    }
];

const QUILL_HOVER_INFO: Record<string, { description: string; example: string }> = {
    'let': {
        description: 'Declares a new variable.',
        example: 'let name be "Alice".'
    },
    'set': {
        description: 'Reassigns an existing variable.',
        example: 'set name to "Bob".'
    },
    'say': {
        description: 'Prints a value to the console.',
        example: 'say "Hello, world!".'
    },
    'if': {
        description: 'Conditional statement. Use with `end if.`',
        example: 'if age is greater than 17.\n  say "Adult.".\nend if.'
    },
    'repeat': {
        description: 'Loop that repeats N times or from a range.',
        example: 'repeat 5 times.\n  say "Hello.".\nend repeat.'
    },
    'define': {
        description: 'Defines a function.',
        example: 'define greet taking name.\n  say "Hello, {name}!".\nend define.'
    },
    'use': {
        description: 'Imports a standard library module.',
        example: 'use math.\nuse files.\nuse web.'
    }
};
