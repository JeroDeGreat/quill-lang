#!/usr/bin/env python3
"""
quill — The Quill Language CLI
Usage:
  quill run <file.ql>          Run a Quill file
  quill run <file.ql> --debug  Run with AST debug output
  quill check <file.ql>        Check syntax without running
  quill repl                   Interactive REPL
  quill new <project>          Create a new project
  quill build <file.ql>        Build standalone executable
  quill version                Print version
  quill help                   Print help
"""
import sys, os, argparse, traceback

QUILL_VERSION = "2.0.0"

HELP_TEXT = """
╔═══════════════════════════════════════════════════════════════╗
║           Quill  —  "Write code the way you think."          ║
╚═══════════════════════════════════════════════════════════════╝

  quill run <file.ql>          Run a Quill file
  quill run <file.ql> --debug  Run with debug output (shows AST)
  quill check <file.ql>        Check syntax without running
  quill repl                   Interactive REPL  (type 'exit.' to quit)
  quill new <project>          Scaffold a new project
  quill build <file.ql>        Build standalone executable
  quill version                Print version info
  quill help                   Show this help

Learn more at https://quill-lang.org
"""

def cmd_run(args):
    path = args.file
    if not os.path.isfile(path):
        print(f"Quill: I cannot find the file \"{path}\".", file=sys.stderr)
        sys.exit(1)

    with open(path, 'r', encoding='utf-8') as f:
        source = f.read()

    from quill.lexer import tokenize
    from quill.parser import parse, ParseError
    from quill.evaluator import Evaluator, QuillRuntimeError

    try:
        tokens = tokenize(source)
        if args.debug:
            print("=== TOKENS ===")
            for t in tokens:
                print(f"  {t}")

        ast = parse(source)
        if args.debug:
            print("\n=== AST ===")
            _print_ast(ast, indent=0)
            print("\n=== OUTPUT ===")

        ev = Evaluator()
        ev.run(ast)

    except ParseError as e:
        print(f"\n✗ Syntax Error\n  {e}", file=sys.stderr)
        _suggest_fix(str(e))
        sys.exit(1)
    except QuillRuntimeError as e:
        print(f"\n✗ Runtime Error\n  {e}", file=sys.stderr)
        sys.exit(1)
    except KeyboardInterrupt:
        print("\n(Interrupted)")
        sys.exit(0)
    except Exception as e:
        print(f"\n✗ Unexpected Error\n  {e}", file=sys.stderr)
        if args.debug:
            traceback.print_exc()
        sys.exit(1)


def cmd_check(args):
    path = args.file
    if not os.path.isfile(path):
        print(f"Quill: I cannot find the file \"{path}\".", file=sys.stderr)
        sys.exit(1)

    with open(path, 'r', encoding='utf-8') as f:
        source = f.read()

    from quill.parser import parse, ParseError
    from quill.lexer import LexError

    try:
        parse(source)
        print(f"✓ \"{path}\" looks good — no syntax errors found.")
    except (ParseError, LexError) as e:
        print(f"✗ {e}", file=sys.stderr)
        sys.exit(1)


def cmd_repl(args):
    from quill.evaluator import Evaluator, QuillRuntimeError
    from quill.parser import parse, ParseError
    from quill.lexer import tokenize, LexError

    try:
        import readline  # noqa: F401 — enables arrow-key history
    except ImportError:
        pass

    ev = Evaluator()
    print(f'Quill {QUILL_VERSION}  —  "Write code the way you think."')
    print('Type "exit." or "quit." to leave.\n')

    block_keywords = {'if', 'repeat', 'while', 'for', 'define', 'try', 'class'}
    end_keywords   = {'end'}
    buffer = []

    def is_open_block(lines):
        depth = 0
        for line in lines:
            words = line.strip().lower().split()
            if not words:
                continue
            if words[0] in block_keywords:
                depth += 1
            if words[0] in end_keywords and len(words) > 1:
                depth -= 1
        return depth > 0

    while True:
        try:
            prompt = '  ... ' if buffer else 'quill> '
            line = input(prompt)
        except (EOFError, KeyboardInterrupt):
            print('\nGoodbye!')
            break

        stripped = line.strip().lower()
        if stripped in ('exit.', 'quit.', 'exit', 'quit'):
            print('Goodbye!')
            break

        buffer.append(line)
        source = '\n'.join(buffer)

        if is_open_block(buffer):
            continue

        try:
            tokens = tokenize(source)
            ast = parse(source)
            result = ev.run(ast)
            if result is not None:
                print(f'=> {_quill_repr(result)}')
        except (ParseError, LexError) as e:
            print(f'  Syntax: {e}')
        except QuillRuntimeError as e:
            print(f'  Error: {e}')
        except Exception as e:
            print(f'  Error: {e}')

        buffer = []


def cmd_new(args):
    name = args.name
    if os.path.exists(name):
        print(f"A folder named \"{name}\" already exists here.", file=sys.stderr)
        sys.exit(1)

    os.makedirs(f'{name}/lib')
    os.makedirs(f'{name}/assets')

    with open(f'{name}/main.ql', 'w') as f:
        f.write(f'note Welcome to {name}!\n\nsay "Hello from {name}!".\n')

    with open(f'{name}/nest.toml', 'w') as f:
        f.write(f'[project]\nname = "{name}"\nversion = "1.0.0"\nauthor = ""\ndescription = "A Quill project"\n\n[dependencies]\n')

    with open(f'{name}/readme.ql.md', 'w') as f:
        f.write(f'# {name}\n\nA Quill project.\n\n## Running\n\n```\nquill run main.ql\n```\n')

    print(f"""
✓ Created project "{name}"!

  {name}/
  ├── main.ql       ← your main program
  ├── nest.toml     ← project config
  ├── lib/          ← your modules
  └── assets/       ← images, data, etc.

Get started:
  cd {name}
  quill run main.ql
""")


def cmd_build(args):
    path = args.file
    if not os.path.isfile(path):
        print(f"Quill: Cannot find \"{path}\".", file=sys.stderr)
        sys.exit(1)

    try:
        import PyInstaller  # noqa
    except ImportError:
        print("Quill: 'quill build' requires PyInstaller.")
        print("  Install it with:  pip install pyinstaller")
        sys.exit(1)

    name = os.path.splitext(os.path.basename(path))[0]
    quill_runner = os.path.join(os.path.dirname(__file__), '__main__.py')

    cmd = [
        sys.executable, '-m', 'PyInstaller',
        '--onefile', '--name', name,
        '--add-data', f'{os.path.dirname(__file__)}{os.pathsep}quill',
        '--hidden-import', 'quill',
        quill_runner
    ]

    if args.gui:
        cmd.append('--windowed')

    import subprocess
    result = subprocess.run(cmd)
    if result.returncode == 0:
        print(f"\n✓ Built!  Find your app at dist/{name}")
    else:
        print("\n✗ Build failed.", file=sys.stderr)
        sys.exit(1)


# ─── Helpers ────────────────────────────────────────────────────────────────

def _quill_repr(v) -> str:
    if v is None:           return 'nothing'
    if isinstance(v, bool): return 'yes' if v else 'no'
    if isinstance(v, list): return '[' + ', '.join(_quill_repr(i) for i in v) + ']'
    if isinstance(v, dict): return '{' + ', '.join(f'{k!r}: {_quill_repr(val)}' for k, val in v.items()) + '}'
    return repr(v)

def _print_ast(node, indent=0):
    prefix = '  ' * indent
    if node is None:
        print(f'{prefix}None')
        return
    name = type(node).__name__
    from dataclasses import fields, is_dataclass
    if is_dataclass(node):
        print(f'{prefix}{name}')
        for field in fields(node):
            val = getattr(node, field.name)
            if isinstance(val, list):
                print(f'{prefix}  {field.name}:')
                for item in val:
                    if hasattr(item, '__dataclass_fields__'):
                        _print_ast(item, indent + 2)
                    else:
                        print(f'{prefix}    {item!r}')
            elif hasattr(val, '__dataclass_fields__'):
                print(f'{prefix}  {field.name}:')
                _print_ast(val, indent + 2)
            else:
                print(f'{prefix}  {field.name}: {val!r}')

def _suggest_fix(error: str):
    if 'period' in error.lower():
        print("  Hint: Every Quill statement must end with a period (.)", file=sys.stderr)
    elif 'end if' in error.lower():
        print("  Hint: Close your if block with \"end if.\"", file=sys.stderr)
    elif 'end repeat' in error.lower():
        print("  Hint: Close your repeat loop with \"end repeat.\"", file=sys.stderr)


# ─── Main ────────────────────────────────────────────────────────────────────

def main():
    parser = argparse.ArgumentParser(prog='quill', add_help=False)
    sub = parser.add_subparsers(dest='command')

    # run
    run_p = sub.add_parser('run')
    run_p.add_argument('file')
    run_p.add_argument('--debug', action='store_true')

    # check
    chk = sub.add_parser('check')
    chk.add_argument('file')

    # repl
    sub.add_parser('repl')

    # new
    new_p = sub.add_parser('new')
    new_p.add_argument('name')

    # build
    bld = sub.add_parser('build')
    bld.add_argument('file')
    bld.add_argument('--gui', action='store_true')

    # version
    sub.add_parser('version')

    # help
    sub.add_parser('help')

    args = parser.parse_args()

    if args.command == 'run':    cmd_run(args)
    elif args.command == 'check': cmd_check(args)
    elif args.command == 'repl':  cmd_repl(args)
    elif args.command == 'new':   cmd_new(args)
    elif args.command == 'build': cmd_build(args)
    elif args.command == 'version':
        print(f"Quill {QUILL_VERSION}")
        print(f"Python {sys.version}")
    elif args.command == 'help':
        print(HELP_TEXT)
    else:
        # If given a .ql file directly: quill myfile.ql
        if len(sys.argv) > 1 and sys.argv[1].endswith('.ql'):
            class FakeArgs:
                file = sys.argv[1]
                debug = '--debug' in sys.argv
            cmd_run(FakeArgs())
        else:
            print(HELP_TEXT)


if __name__ == '__main__':
    main()
