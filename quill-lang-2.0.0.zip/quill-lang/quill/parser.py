"""
Quill Recursive-Descent Parser.

Consumes a token stream from the lexer and produces an AST.
Multi-word keywords are handled by peeking at sequences of WORD tokens.
"""
from __future__ import annotations
from typing import List, Optional, Tuple
from .lexer import Token, TT
from .ast_nodes import *


class ParseError(Exception):
    def __init__(self, msg: str, line: int):
        super().__init__(f"Error on line {line}: {msg}")
        self.line = line


class Parser:
    def __init__(self, tokens: List[Token]):
        # Filter out pure NEWLINE tokens between statements to simplify parsing
        # We keep them for context but the parser mainly cares about INDENT/DEDENT/EOF/PERIOD
        self.tokens = [t for t in tokens if t.type not in (TT.NEWLINE,)]
        self.pos = 0

    # ─── Token navigation ───────────────────────────────────────────────

    def peek(self, offset: int = 0) -> Token:
        idx = self.pos + offset
        if idx < len(self.tokens):
            return self.tokens[idx]
        return self.tokens[-1]  # EOF

    def peek_word(self, offset: int = 0) -> str:
        t = self.peek(offset)
        if t.type == TT.WORD:
            return t.value
        return ""

    def advance(self) -> Token:
        t = self.tokens[self.pos]
        if self.pos < len(self.tokens) - 1:
            self.pos += 1
        return t

    def current_line(self) -> int:
        return self.peek().line

    def error(self, msg: str) -> ParseError:
        return ParseError(msg, self.current_line())

    def expect_word(self, *words: str) -> Token:
        t = self.peek()
        if t.type != TT.WORD or t.value not in words:
            raise self.error(
                f'I expected "{" or ".join(words)}" but found "{t.value if t.type == TT.WORD else t.type.name}".'
            )
        return self.advance()

    def expect_period(self):
        t = self.peek()
        if t.type != TT.PERIOD:
            raise self.error(
                f'I expected a period "." to end this statement, but found '
                f'"{t.value if t.type == TT.WORD else t.type.name}" instead.'
            )
        self.advance()

    def match_word(self, *words: str) -> bool:
        if self.peek().type == TT.WORD and self.peek().value in words:
            self.advance()
            return True
        return False

    def match_words(self, *sequence: str) -> bool:
        """Check if the next N tokens are WORDs matching the given sequence."""
        for i, w in enumerate(sequence):
            t = self.peek(i)
            if t.type != TT.WORD or t.value != w:
                return False
        for _ in sequence:
            self.advance()
        return True

    def peek_words(self, *sequence: str) -> bool:
        for i, w in enumerate(sequence):
            t = self.peek(i)
            if t.type != TT.WORD or t.value != w:
                return False
        return True

    def expect_type(self, tt: TT) -> Token:
        t = self.peek()
        if t.type != tt:
            raise self.error(f"Expected {tt.name} but found {t.type.name} ({t.value!r})")
        return self.advance()

    # ─── Entry point ────────────────────────────────────────────────────

    def parse(self) -> Program:
        prog = Program(line=1)
        prog.statements = self.parse_block_until(lambda: self.peek().type == TT.EOF)
        return prog

    # ─── Block parsing ──────────────────────────────────────────────────

    def parse_block(self) -> List[Node]:
        """Parse an indented block (after INDENT token, before matching DEDENT)."""
        stmts = []
        if self.peek().type == TT.INDENT:
            self.advance()  # consume INDENT
            while self.peek().type not in (TT.DEDENT, TT.EOF):
                s = self.parse_statement()
                if s:
                    stmts.append(s)
            if self.peek().type == TT.DEDENT:
                self.advance()  # consume DEDENT
        else:
            # single-line body — try one statement
            s = self.parse_statement()
            if s:
                stmts.append(s)
        return stmts

    def parse_block_until(self, stop_fn) -> List[Node]:
        stmts = []
        while not stop_fn():
            if self.peek().type in (TT.INDENT, TT.DEDENT):
                self.advance()
                continue
            s = self.parse_statement()
            if s:
                stmts.append(s)
        return stmts

    def is_end_keyword(self) -> bool:
        return self.peek_words('end') and self.peek(1).type == TT.WORD

    # ─── Statement dispatch ─────────────────────────────────────────────

    def parse_statement(self) -> Optional[Node]:
        line = self.current_line()
        t = self.peek()

        if t.type == TT.PERIOD:
            self.advance()
            return None

        if t.type != TT.WORD:
            self.advance()
            return None

        w = t.value

        # ── Declarations ──────────────────────────────────────────────────
        if w == 'let':
            return self.parse_let(line)
        if w == 'set':
            return self.parse_set(line)

        # ── I/O ──────────────────────────────────────────────────────────
        if w in ('say', 'print', 'display'):
            return self.parse_say(line)
        if w == 'ask':
            return self.parse_ask(line)

        # ── Control flow ─────────────────────────────────────────────────
        if w == 'if':
            return self.parse_if(line)
        if w == 'repeat':
            return self.parse_repeat(line)
        if w == 'while':
            return self.parse_while(line)
        if w == 'for':
            return self.parse_for(line)
        if w == 'stop':
            self.advance(); self.expect_period()
            return StopStatement(line=line)
        if w == 'skip':
            self.advance(); self.expect_period()
            return SkipStatement(line=line)
        if w == 'return':
            return self.parse_return(line)

        # ── Definitions ──────────────────────────────────────────────────
        if w == 'define':
            return self.parse_define(line)

        # ── Error handling ────────────────────────────────────────────────
        if w == 'try':
            return self.parse_try(line)
        if w == 'raise':
            return self.parse_raise(line)

        # ── Modules ───────────────────────────────────────────────────────
        if w == 'use':
            return self.parse_use(line)

        # ── List / map mutation ──────────────────────────────────────────
        if w == 'add':
            return self.parse_add(line)
        if w == 'remove':
            return self.parse_remove(line)
        if w == 'subtract':
            return self.parse_subtract(line)
        if w == 'multiply':
            return self.parse_multiply(line)
        if w == 'divide':
            return self.parse_divide(line)

        # ── File I/O ──────────────────────────────────────────────────────
        if w == 'write':
            return self.parse_write(line)
        if w == 'append':
            return self.parse_append(line)
        if w == 'delete':
            return self.parse_delete(line)

        # ── call X on Y ──────────────────────────────────────────────────
        if w == 'call':
            return self.parse_call_on(line)

        # ── run command ──────────────────────────────────────────────────
        if w == 'run':
            return self.parse_run(line)

        # ── GUI statements ───────────────────────────────────────────────
        if w == 'open':
            return self.parse_open_window(line)
        if w == 'create':
            return self.parse_create_widget(line)
        if w == 'place':
            return self.parse_place_in_window(line)
        if w == 'show':
            return self.parse_show_window(line)
        if w == 'when':
            return self.parse_when(line)

        # ── end X  — consumed by callers, but handle stray ones ──────────
        if w == 'end':
            # consume silently so we don't loop forever
            self.advance()
            if self.peek().type == TT.WORD:
                self.advance()
            if self.peek().type == TT.PERIOD:
                self.advance()
            return None

        # ── else / else if — handled by if parser, skip stray ────────────
        if w in ('else',):
            self.advance()
            return None

        # ── catch — handled by try parser ────────────────────────────────
        if w == 'catch':
            self.advance()
            return None

        # ── Bare function call:  NAME.  or  NAME with ARGS. ─────────────
        return self.parse_expr_statement(line)

    # ─── Let statement ──────────────────────────────────────────────────

    def parse_let(self, line: int) -> LetStatement:
        self.advance()  # consume 'let'

        names = [self.expect_type(TT.WORD).value]
        while self.peek().type == TT.COMMA:
            self.advance()
            names.append(self.expect_type(TT.WORD).value)

        # Optional type annotation:  as TYPE
        type_ann = None
        if self.peek_words('as'):
            self.advance()
            type_ann = self.expect_type(TT.WORD).value

        self.expect_word('be')

        # Special "be a list of …"
        if self.peek_words('a', 'list', 'of'):
            self.advance(); self.advance(); self.advance()
            items = self.parse_expr_list()
            self.expect_period()
            return LetStatement(names=names, values=[ListLiteral(items=items, line=line)],
                                type_annotation=type_ann, line=line)

        if self.peek_words('an', 'empty', 'list'):
            self.advance(); self.advance(); self.advance()
            self.expect_period()
            return LetStatement(names=names, values=[ListLiteral(items=[], line=line)],
                                type_annotation=type_ann, line=line)

        if self.peek_words('a', 'map', 'with'):
            self.advance(); self.advance(); self.advance()
            pairs = self.parse_map_pairs()
            self.expect_period()
            return LetStatement(names=names, values=[MapLiteral(pairs=pairs, line=line)],
                                type_annotation=type_ann, line=line)

        if self.peek_words('a', 'new'):
            self.advance(); self.advance()
            cls = self.expect_type(TT.WORD).value
            args = []
            if self.match_word('with'):
                args = self.parse_expr_list()
            self.expect_period()
            return LetStatement(names=names, values=[NewObject(class_name=cls, args=args, line=line)],
                                type_annotation=type_ann, line=line)

        if self.peek_words('a', 'function', 'taking'):
            self.advance(); self.advance(); self.advance()
            params = self.parse_param_list()
            self.expect_word('that')
            self.expect_word('returns')
            body = self.parse_expr()
            self.expect_period()
            return LetStatement(names=names,
                                values=[InlineFunction(params=params, body=body, line=line)],
                                type_annotation=type_ann, line=line)

        # Multi-assign or single expression(s)
        values = [self.parse_expr()]
        while self.peek().type == TT.COMMA and len(names) > 1:
            self.advance()
            values.append(self.parse_expr())

        self.expect_period()
        return LetStatement(names=names, values=values, type_annotation=type_ann, line=line)

    # ─── Set statement ──────────────────────────────────────────────────

    def parse_set(self, line: int) -> Node:
        self.advance()  # consume 'set'

        # set item N of LIST to VALUE
        if self.match_word('item'):
            idx = self.parse_expr()
            self.expect_word('of')
            target = self.expect_type(TT.WORD).value
            self.expect_word('to')
            val = self.parse_expr()
            self.expect_period()
            return SetItemStatement(target=target, key=idx, value=val, is_map=False, line=line)

        # set its PROP to VALUE
        if self.match_word('its'):
            prop = self.expect_type(TT.WORD).value
            self.expect_word('to')
            val = self.parse_expr()
            self.expect_period()
            return SetPropertyStatement(prop=prop, value=val, line=line)

        # set the text of WIDGET to VALUE
        if self.peek_words('the', 'text', 'of'):
            self.advance(); self.advance(); self.advance()
            widget = self.expect_type(TT.WORD).value
            self.expect_word('to')
            val = self.parse_expr()
            self.expect_period()
            return SetTextStatement(widget=widget, value=val, line=line)

        # set the background color / color / font size / width / padding
        if self.peek_words('the') or self.peek_words('color') or self.peek_words('font') or \
           self.peek_words('width') or self.peek_words('background') or self.peek_words('padding'):
            # GUI property set — consume until 'to' and treat as no-op for now
            while not self.peek_words('to') and self.peek().type not in (TT.PERIOD, TT.EOF):
                self.advance()
            if self.match_word('to'):
                val = self.parse_expr()
            self.expect_period()
            return None

        # set NAME at KEY to VALUE  (map)
        name = self.expect_type(TT.WORD).value
        if self.match_word('at'):
            key = self.parse_expr()
            self.expect_word('to')
            val = self.parse_expr()
            self.expect_period()
            return SetItemStatement(target=name, key=key, value=val, is_map=True, line=line)

        # set NAME to VALUE
        self.expect_word('to')
        val = self.parse_expr()
        self.expect_period()
        return SetStatement(name=name, value=val, line=line)

    # ─── Say / print / display ──────────────────────────────────────────

    def parse_say(self, line: int) -> SayStatement:
        self.advance()  # consume 'say'/'print'/'display'
        val = self.parse_expr()
        # say X followed by Y  /  say X and Y
        followed = None
        if self.match_word('followed'):
            self.expect_word('by')
            followed = self.parse_expr()
        elif self.match_word('and'):
            followed = self.parse_expr()
        self.expect_period()
        return SayStatement(value=val, followed_by=followed, line=line)

    # ─── Ask ────────────────────────────────────────────────────────────

    def parse_ask(self, line: int) -> AskStatement:
        self.advance()  # consume 'ask'
        prompt = self.parse_expr()
        self.expect_word('into')
        var = self.expect_type(TT.WORD).value
        type_ann = None
        if self.match_word('as'):
            type_ann = self.expect_type(TT.WORD).value
        self.expect_period()
        return AskStatement(prompt=prompt, variable=var, type_annotation=type_ann, line=line)

    # ─── If statement ───────────────────────────────────────────────────

    def parse_if(self, line: int) -> IfStatement:
        self.advance()  # consume 'if'
        cond = self.parse_condition()
        self.expect_period()
        then_body = self.parse_block()

        elif_clauses = []
        else_body = None

        while self.peek_words('else'):
            self.advance()  # consume 'else'
            if self.peek_words('if'):
                self.advance()  # consume 'if'
                ec = self.parse_condition()
                self.expect_period()
                eb = self.parse_block()
                elif_clauses.append((ec, eb))
            else:
                self.expect_period()
                else_body = self.parse_block()
                break

        # expect end if.
        if self.peek_words('end', 'if'):
            self.advance(); self.advance()
            self.expect_period()

        return IfStatement(condition=cond, then_body=then_body,
                           elif_clauses=elif_clauses, else_body=else_body, line=line)

    # ─── Repeat ─────────────────────────────────────────────────────────

    def parse_repeat(self, line: int) -> Node:
        self.advance()  # consume 'repeat'

        if self.peek_words('from'):
            self.advance()
            start = self.parse_expr()
            self.expect_word('to')
            end = self.parse_expr()
            self.expect_period()
            body = self.parse_block()
            if self.peek_words('end', 'repeat'):
                self.advance(); self.advance(); self.expect_period()
            return RepeatRangeStatement(start=start, end=end, body=body, line=line)

        # Use parse_primary so 'times' isn't consumed as a multiplication operator
        count = self.parse_primary()
        self.expect_word('times')
        self.expect_period()
        body = self.parse_block()
        if self.peek_words('end', 'repeat'):
            self.advance(); self.advance(); self.expect_period()
        return RepeatTimesStatement(count=count, body=body, line=line)

    # ─── While ──────────────────────────────────────────────────────────

    def parse_while(self, line: int) -> WhileStatement:
        self.advance()  # consume 'while'
        cond = self.parse_condition()
        self.expect_period()
        body = self.parse_block()
        if self.peek_words('end', 'while'):
            self.advance(); self.advance(); self.expect_period()
        return WhileStatement(condition=cond, body=body, line=line)

    # ─── For each ───────────────────────────────────────────────────────

    def parse_for(self, line: int) -> Node:
        self.advance()  # consume 'for'
        self.expect_word('each')
        var = self.expect_type(TT.WORD).value
        self.expect_word('in')
        iterable = self.parse_expr()
        self.expect_period()
        body = self.parse_block()
        if self.peek_words('end', 'for'):
            self.advance(); self.advance(); self.expect_period()
        return ForEachStatement(variable=var, iterable=iterable, body=body, line=line)

    # ─── Define ─────────────────────────────────────────────────────────

    def parse_define(self, line: int) -> Node:
        self.advance()  # consume 'define'

        # define class …
        if self.match_word('class'):
            return self.parse_define_class(line)

        name = self.expect_type(TT.WORD).value
        params = []
        defaults = {}

        if self.match_word('taking'):
            params = self.parse_param_list()
            # check for 'with default VALUE'
            if self.peek_words('with', 'default'):
                self.advance(); self.advance()
                dv = self.parse_expr()
                if params:
                    defaults[params[-1]] = dv

        self.expect_period()
        body = self.parse_block()
        if self.peek_words('end', 'define'):
            self.advance(); self.advance(); self.expect_period()
        return DefineStatement(name=name, params=params, defaults=defaults, body=body, line=line)

    def parse_define_class(self, line: int) -> DefineClassStatement:
        name = self.expect_type(TT.WORD).value
        parent = None
        if self.match_word('extending'):
            parent = self.expect_type(TT.WORD).value
        self.expect_period()

        attributes = []
        methods = []

        # consume optional INDENT
        if self.peek().type == TT.INDENT:
            self.advance()

        while not (self.peek_words('end', 'class') or self.peek().type in (TT.DEDENT, TT.EOF)):
            t = self.peek()
            if t.type == TT.WORD and t.value == 'it':
                self.advance()  # consume 'it'
                self.expect_word('has')
                while self.peek().type == TT.WORD:
                    attributes.append(self.advance().value)
                    if self.peek().type == TT.COMMA:
                        self.advance()
                    else:
                        break
                if self.peek().type == TT.PERIOD:
                    self.advance()
            elif t.type == TT.WORD and t.value == 'define':
                methods.append(self.parse_define(t.line))
            elif t.type in (TT.INDENT, TT.DEDENT):
                self.advance()
            else:
                self.advance()

        if self.peek().type == TT.DEDENT:
            self.advance()
        if self.peek_words('end', 'class'):
            self.advance(); self.advance(); self.expect_period()

        return DefineClassStatement(name=name, parent=parent,
                                    attributes=attributes, methods=methods, line=line)

    # ─── Try / catch ────────────────────────────────────────────────────

    def parse_try(self, line: int) -> TryStatement:
        self.advance()  # consume 'try'
        self.expect_period()
        try_body = self.parse_block()

        error_var = 'error'
        if self.peek_words('catch'):
            self.advance()
            if self.peek().type == TT.WORD:
                error_var = self.advance().value
            self.expect_period()

        catch_body = self.parse_block()
        if self.peek_words('end', 'try'):
            self.advance(); self.advance(); self.expect_period()
        return TryStatement(try_body=try_body, error_var=error_var, catch_body=catch_body, line=line)

    # ─── Raise ──────────────────────────────────────────────────────────

    def parse_raise(self, line: int) -> RaiseStatement:
        self.advance()  # consume 'raise'
        self.match_word('error')  # optional word 'error'
        msg = self.parse_expr()
        self.expect_period()
        return RaiseStatement(message=msg, line=line)

    # ─── Use ────────────────────────────────────────────────────────────

    def parse_use(self, line: int) -> UseStatement:
        self.advance()  # consume 'use'
        t = self.peek()

        # use python "lib" as alias
        if t.type == TT.WORD and t.value in ('python', 'javascript', 'js'):
            lang = self.advance().value
            mod = self.expect_type(TT.STRING).value
            alias = None
            if self.match_word('as'):
                alias = self.expect_type(TT.WORD).value
            self.expect_period()
            return UseStatement(module=mod, language=lang, alias=alias, line=line)

        # use MODNAME [as ALIAS]
        if t.type == TT.WORD:
            mod = self.advance().value
            alias = None
            if self.match_word('as'):
                alias = self.expect_type(TT.WORD).value
            self.expect_period()
            return UseStatement(module=mod, alias=alias, line=line)

        raise self.error("Expected a module name after 'use'.")

    # ─── Add ────────────────────────────────────────────────────────────

    def parse_add(self, line: int) -> Node:
        self.advance()  # consume 'add'

        # Special case: 'add row ...' handled by v2 patch
        if self.peek_words('row'):
            return _parse_add_row(self, line)

        val = self.parse_expr()

        # If there's a comma, this is 'add A, B, C to LAYOUT'
        if self.peek().type == TT.COMMA:
            widgets = [val.name if hasattr(val, 'name') else str(val)]
            while self.peek().type == TT.COMMA:
                self.advance()
                w = self.parse_expr()
                widgets.append(w.name if hasattr(w, 'name') else str(w))
            self.expect_word('to')
            layout = self.expect_type(TT.WORD).value
            self.expect_period()
            from .ast_nodes import AddToLayoutStatement
            return AddToLayoutStatement(widgets=widgets, layout=layout, line=line)

        self.expect_word('to')
        target = self.expect_type(TT.WORD).value
        self.expect_period()
        return AddToStatement(value=val, target=target, line=line)

    # ─── Remove ─────────────────────────────────────────────────────────

    def parse_remove(self, line: int) -> Node:
        self.advance()  # consume 'remove'
        val = self.parse_expr()
        self.expect_word('from')
        target = self.expect_type(TT.WORD).value
        self.expect_period()
        return RemoveFromStatement(value=val, target=target, line=line)

    # ─── Subtract ───────────────────────────────────────────────────────

    def parse_subtract(self, line: int) -> Node:
        self.advance()  # consume 'subtract'
        val = self.parse_expr()
        self.expect_word('from')
        target = self.expect_type(TT.WORD).value
        self.expect_period()
        return SubtractFromStatement(value=val, target=target, line=line)

    # ─── Multiply ───────────────────────────────────────────────────────

    def parse_multiply(self, line: int) -> Node:
        self.advance()  # consume 'multiply'
        target = self.expect_type(TT.WORD).value
        self.expect_word('by')
        val = self.parse_expr()
        self.expect_period()
        return MultiplyByStatement(target=target, value=val, line=line)

    # ─── Divide ─────────────────────────────────────────────────────────

    def parse_divide(self, line: int) -> Node:
        self.advance()  # consume 'divide'
        target = self.expect_type(TT.WORD).value
        self.expect_word('by')
        val = self.parse_expr()
        self.expect_period()
        return DivideByStatement(target=target, value=val, line=line)

    # ─── Write file ─────────────────────────────────────────────────────

    def parse_write(self, line: int) -> WriteFileStatement:
        self.advance()  # consume 'write'
        content = self.parse_expr()
        self.expect_word('to')
        self.expect_word('file')
        fname = self.parse_expr()
        self.expect_period()
        return WriteFileStatement(content=content, filename=fname, mode='w', line=line)

    def parse_append(self, line: int) -> WriteFileStatement:
        self.advance()  # consume 'append'
        content = self.parse_expr()
        self.expect_word('to')
        self.expect_word('file')
        fname = self.parse_expr()
        self.expect_period()
        return WriteFileStatement(content=content, filename=fname, mode='a', line=line)

    def parse_delete(self, line: int) -> DeleteFileStatement:
        self.advance()  # consume 'delete'
        self.expect_word('file')
        fname = self.parse_expr()
        self.expect_period()
        return DeleteFileStatement(filename=fname, line=line)

    # ─── Call on ────────────────────────────────────────────────────────

    def parse_call_on(self, line: int) -> Node:
        self.advance()  # consume 'call'
        method = self.expect_type(TT.WORD).value
        self.expect_word('on')
        obj = self.expect_type(TT.WORD).value
        args = []
        if self.match_word('with'):
            args = self.parse_expr_list()
        self.expect_period()
        return CallOnStatement(method=method, obj=obj, args=args, line=line)

    # ─── Run command ────────────────────────────────────────────────────

    def parse_run(self, line: int) -> Node:
        self.advance()  # consume 'run'
        self.expect_word('command')
        cmd = self.parse_expr()
        var = None
        if self.match_word('into'):
            var = self.expect_type(TT.WORD).value
        self.expect_period()
        # Represent as function call
        args = [cmd]
        if var:
            # We'll handle this by wrapping in let
            # For now, just exec statement
            pass
        call = FunctionCall(name='__run_command__', args=args, line=line)
        if var:
            return LetStatement(names=[var], values=[call], line=line)
        return ExprStatement(expr=call, line=line)

    # ─── Return ─────────────────────────────────────────────────────────

    def parse_return(self, line: int) -> ReturnStatement:
        self.advance()  # consume 'return'
        if self.peek().type == TT.PERIOD:
            self.advance()
            return ReturnStatement(value=None, line=line)
        val = self.parse_expr()
        self.expect_period()
        return ReturnStatement(value=val, line=line)

    # ─── Expression statement ────────────────────────────────────────────

    def parse_expr_statement(self, line: int) -> Optional[Node]:
        expr = self.parse_expr()
        if self.peek().type == TT.PERIOD:
            self.advance()
        return ExprStatement(expr=expr, line=line)

    # ═══════════════════════════════════════════════════════════════════════
    # Expression parsing (operator precedence, bottom-up)
    # ═══════════════════════════════════════════════════════════════════════

    def parse_expr(self) -> Node:
        return self.parse_or()

    def parse_or(self) -> Node:
        left = self.parse_and()
        while self.peek_words('or'):
            self.advance()
            right = self.parse_and()
            left = LogicalOp(op='or', left=left, right=right, line=left.line)
        return left

    def parse_and(self) -> Node:
        left = self.parse_not()
        while self.peek_words('and'):
            self.advance()
            right = self.parse_not()
            left = LogicalOp(op='and', left=left, right=right, line=left.line)
        return left

    def parse_not(self) -> Node:
        if self.peek_words('not'):
            line = self.current_line()
            self.advance()
            operand = self.parse_not()
            return UnaryOp(op='not', operand=operand, line=line)
        return self.parse_comparison()

    def parse_comparison(self) -> Node:
        left = self.parse_addition()
        line = left.line

        if self.peek_words('is', 'greater', 'than'):
            self.advance(); self.advance(); self.advance()
            return CompareOp(op='>', left=left, right=self.parse_addition(), line=line)
        if self.peek_words('is', 'less', 'than'):
            self.advance(); self.advance(); self.advance()
            return CompareOp(op='<', left=left, right=self.parse_addition(), line=line)
        if self.peek_words('is', 'at', 'least'):
            self.advance(); self.advance(); self.advance()
            return CompareOp(op='>=', left=left, right=self.parse_addition(), line=line)
        if self.peek_words('is', 'at', 'most'):
            self.advance(); self.advance(); self.advance()
            return CompareOp(op='<=', left=left, right=self.parse_addition(), line=line)
        if self.peek_words('is', 'not'):
            self.advance(); self.advance()
            return CompareOp(op='!=', left=left, right=self.parse_addition(), line=line)
        if self.peek_words('is', 'nothing'):
            self.advance(); self.advance()
            return CompareOp(op='is_nothing', left=left, right=NothingLiteral(line=line), line=line)
        if self.peek_words('is'):
            self.advance()
            return CompareOp(op='==', left=left, right=self.parse_addition(), line=line)

        return left

    def parse_addition(self) -> Node:
        left = self.parse_multiplication()
        while True:
            if self.peek_words('plus'):
                self.advance()
                right = self.parse_multiplication()
                left = BinaryOp(op='+', left=left, right=right, line=left.line)
            elif self.peek_words('minus'):
                self.advance()
                right = self.parse_multiplication()
                left = BinaryOp(op='-', left=left, right=right, line=left.line)
            else:
                break
        return left

    def parse_multiplication(self) -> Node:
        left = self.parse_unary()
        while True:
            if self.peek_words('times'):
                self.advance()
                right = self.parse_unary()
                left = BinaryOp(op='*', left=left, right=right, line=left.line)
            elif self.peek_words('divided', 'by'):
                self.advance(); self.advance()
                right = self.parse_unary()
                left = BinaryOp(op='/', left=left, right=right, line=left.line)
            elif self.peek_words('mod'):
                self.advance()
                right = self.parse_unary()
                left = BinaryOp(op='%', left=left, right=right, line=left.line)
            elif self.peek_words('to', 'the', 'power', 'of'):
                self.advance(); self.advance(); self.advance(); self.advance()
                right = self.parse_unary()
                left = BinaryOp(op='**', left=left, right=right, line=left.line)
            else:
                break
        return left

    def parse_unary(self) -> Node:
        if self.peek_words('negative'):
            line = self.current_line()
            self.advance()
            return UnaryOp(op='neg', operand=self.parse_primary(), line=line)
        return self.parse_postfix()

    def parse_postfix(self) -> Node:
        node = self.parse_primary()

        # Postfix operators: "in uppercase", "in lowercase", "trimmed",
        # "joined with X", "split by X", "contains X", "starts with X",
        # "ends with X", "with X replaced by Y", "at KEY"
        while True:
            if self.peek_words('in', 'uppercase'):
                self.advance(); self.advance()
                node = StringOp(op='upper', target=node, line=node.line)
            elif self.peek_words('in', 'lowercase'):
                self.advance(); self.advance()
                node = StringOp(op='lower', target=node, line=node.line)
            elif self.peek_words('trimmed'):
                self.advance()
                node = StringOp(op='trim', target=node, line=node.line)
            elif self.peek_words('joined', 'with'):
                self.advance(); self.advance()
                arg = self.parse_primary()
                node = StringOp(op='join', target=node, arg=arg, line=node.line)
            elif self.peek_words('split', 'by'):
                self.advance(); self.advance()
                # Special case: "split by a new line" → split on \n
                if self.peek_words('a', 'new', 'line') or self.peek_words('a', 'newline'):
                    # consume the words
                    self.advance()
                    self.advance()
                    if self.peek_words('line'):
                        self.advance()
                    arg = StringLiteral(value='\n', line=node.line)
                elif self.peek_words('newlines') or self.peek_words('newline'):
                    self.advance()
                    arg = StringLiteral(value='\n', line=node.line)
                else:
                    arg = self.parse_primary()
                node = StringOp(op='split', target=node, arg=arg, line=node.line)
            elif self.peek_words('contains'):
                self.advance()
                arg = self.parse_primary()
                node = StringOp(op='contains', target=node, arg=arg, line=node.line)
            elif self.peek_words('starts', 'with'):
                self.advance(); self.advance()
                arg = self.parse_primary()
                node = StringOp(op='starts_with', target=node, arg=arg, line=node.line)
            elif self.peek_words('ends', 'with'):
                self.advance(); self.advance()
                arg = self.parse_primary()
                node = StringOp(op='ends_with', target=node, arg=arg, line=node.line)
            elif self.peek_words('with'):
                # "with X replaced by Y"
                saved = self.pos
                self.advance()
                arg = self.parse_primary()
                if self.peek_words('replaced', 'by'):
                    self.advance(); self.advance()
                    arg2 = self.parse_primary()
                    node = StringOp(op='replace', target=node, arg=arg, arg2=arg2, line=node.line)
                else:
                    self.pos = saved
                    break
            elif self.peek_words('at') and isinstance(node, VariableRef):
                self.advance()
                key = self.parse_primary()
                node = MapAccess(map_expr=node, key=key, line=node.line)
            else:
                break

        return node

    def parse_primary(self) -> Node:
        t = self.peek()
        line = t.line

        # Literals
        if t.type == TT.NUMBER:
            self.advance()
            return NumberLiteral(value=t.value, line=line)
        if t.type == TT.DECIMAL:
            self.advance()
            return DecimalLiteral(value=t.value, line=line)
        if t.type == TT.STRING:
            self.advance()
            return StringLiteral(value=t.value, line=line)

        if t.type == TT.WORD:
            w = t.value

            if w == 'yes':
                self.advance()
                return BoolLiteral(value=True, line=line)
            if w == 'no':
                self.advance()
                return BoolLiteral(value=False, line=line)
            if w == 'nothing':
                self.advance()
                return NothingLiteral(line=line)

            # "the …" forms
            if w == 'the':
                return self.parse_the_expr(line)

            # "a" or "an" list/map literals in expression context
            if w == 'a' and self.peek_words('a', 'list', 'of'):
                self.advance(); self.advance(); self.advance()
                items = self.parse_expr_list()
                return ListLiteral(items=items, line=line)
            if w == 'an' and self.peek_words('an', 'empty', 'list'):
                self.advance(); self.advance(); self.advance()
                return ListLiteral(items=[], line=line)
            if w == 'a' and self.peek_words('a', 'new'):
                self.advance(); self.advance()
                cls = self.expect_type(TT.WORD).value
                args = []
                if self.match_word('with'):
                    args = self.parse_expr_list()
                return NewObject(class_name=cls, args=args, line=line)

            # square root of X
            if w == 'square' and self.peek_words('square', 'root', 'of'):
                self.advance(); self.advance(); self.advance()
                operand = self.parse_primary()
                return MathExpr(op='sqrt', operand=operand, line=line)

            # raise X to the power of Y
            if w == 'raise':
                self.advance()
                base = self.parse_primary()
                if self.peek_words('to', 'the', 'power', 'of'):
                    self.advance(); self.advance(); self.advance(); self.advance()
                    exp = self.parse_primary()
                    return MathExpr(op='power', operand=base, arg=exp, line=line)
                return base

            # remainder of X divided by Y
            if w == 'remainder':
                self.advance()
                self.match_word('of')
                a = self.parse_primary()
                if self.peek_words('divided', 'by'):
                    self.advance(); self.advance()
                    b = self.parse_primary()
                    return MathExpr(op='mod', operand=a, arg=b, line=line)
                return a

            # absolute value of X
            if w == 'absolute':
                self.advance()
                self.match_word('value'); self.match_word('of')
                operand = self.parse_primary()
                return MathExpr(op='abs', operand=operand, line=line)

            # round / floor / ceiling / ceil
            if w in ('round', 'floor', 'ceiling', 'ceil'):
                self.advance()
                self.match_word('of')
                operand = self.parse_primary()
                return MathExpr(op=w if w != 'ceiling' else 'ceil', operand=operand, line=line)

            # type of X
            if w == 'type' and self.peek_words('type', 'of'):
                self.advance(); self.advance()
                return TypeOf(target=self.parse_primary(), line=line)

            # fetch "URL"
            if w == 'fetch':
                self.advance()
                url = self.parse_primary()
                return FetchExpr(url=url, line=line)

            # parse X as json
            if w == 'parse':
                self.advance()
                target = self.parse_primary()
                self.match_word('as'); self.match_word('json')
                return ParseJsonExpr(target=target, line=line)

            # its PROP (inside class methods)
            if w == 'its':
                self.advance()
                prop = self.expect_type(TT.WORD).value
                return ItsRef(prop=prop, line=line)

            # random number between X and Y
            if w == 'random' and self.peek_words('random', 'number', 'between'):
                self.advance(); self.advance(); self.advance()  # consume random number between
                low = self.parse_primary()
                self.expect_word('and')
                high = self.parse_primary()
                return RandomBetweenExpr(low=low, high=high, line=line)

            # random number (no range)
            if w == 'random' and self.peek_words('random', 'number'):
                self.advance(); self.advance()
                return RandomBetweenExpr(low=NumberLiteral(value=1, line=line),
                                         high=NumberLiteral(value=100, line=line), line=line)

            # file X exists  (used in if conditions directly)
            if w == 'file':
                self.advance()  # consume 'file'
                fname = self.parse_primary()
                self.match_word('exists')
                return FileExistsExpr(filename=fname, line=line)

            # a new LINE  (skip 'a')  -- handled above in let statement path

            # FUNCNAME with ARGS  or  FUNCNAME alone
            name = self.advance().value  # consume identifier

            if self.match_word('with'):
                args = self.parse_expr_list()
                return FunctionCall(name=name, args=args, line=line)

            # item N of LIST
            # Already handled in parse_the_expr; this is bare variable
            return VariableRef(name=name, line=line)

        # Fallback — something we can't parse
        raise self.error(f'I do not know how to parse this expression starting with "{t.value if t.type == TT.WORD else t.type.name}".')

    def parse_the_expr(self, line: int) -> Node:
        self.advance()  # consume 'the'

        if self.peek_words('size', 'of'):
            self.advance(); self.advance()
            target = self.parse_primary()
            return SizeOf(target=target, line=line)

        if self.peek_words('length', 'of'):
            self.advance(); self.advance()
            target = self.parse_primary()
            return LengthOf(target=target, line=line)

        if self.peek_words('content', 'of', 'file'):
            self.advance(); self.advance(); self.advance()
            fname = self.parse_primary()
            return FileContentExpr(filename=fname, line=line)

        # "file X exists" — as a standalone condition
        if self.peek_words('file'):
            self.advance()  # consume 'file'
            fname = self.parse_primary()
            self.match_word('exists')
            return FileExistsExpr(filename=fname, line=line)

        if self.peek_words('first', 'item', 'in'):
            self.advance(); self.advance(); self.advance()
            lst = self.parse_primary()
            return ListAccess(list_expr=lst, index=StringLiteral(value='first', line=line), line=line)

        if self.peek_words('last', 'item', 'in'):
            self.advance(); self.advance(); self.advance()
            lst = self.parse_primary()
            return ListAccess(list_expr=lst, index=StringLiteral(value='last', line=line), line=line)

        # "item N of LIST"
        if self.peek_words('item'):
            self.advance()  # consume 'item'
            idx = self.parse_primary()
            self.match_word('of')
            lst = self.parse_primary()
            return ListAccess(list_expr=lst, index=idx, line=line)

        if self.peek_words('current', 'count'):
            self.advance(); self.advance()
            return CurrentCount(line=line)

        if self.peek_words('value', 'of'):
            self.advance(); self.advance()
            widget = self.expect_type(TT.WORD).value
            return ValueOf(widget=widget, line=line)

        # "the NAME" — treat as variable
        name = self.expect_type(TT.WORD).value
        return VariableRef(name=name, line=line)

    # ─── Condition parsing (same as expression) ──────────────────────────

    def parse_condition(self) -> Node:
        return self.parse_expr()

    # ─── Helpers ────────────────────────────────────────────────────────

    def parse_expr_list(self) -> List[Node]:
        """Parse comma-separated list of expressions."""
        items = [self.parse_expr()]
        while self.peek().type == TT.COMMA:
            self.advance()
            if self.peek().type in (TT.PERIOD, TT.EOF, TT.DEDENT):
                break
            items.append(self.parse_expr())
        return items

    def parse_map_pairs(self) -> List[Tuple]:
        """Parse  KEY as VALUE, KEY as VALUE, …"""
        pairs = []
        while True:
            key = self.parse_expr()
            self.expect_word('as')
            val = self.parse_expr()
            pairs.append((key, val))
            if self.peek().type == TT.COMMA:
                self.advance()
            else:
                break
        return pairs

    def parse_param_list(self) -> List[str]:
        """Parse comma-separated parameter names."""
        params = [self.expect_type(TT.WORD).value]
        while self.peek().type == TT.COMMA:
            self.advance()
            params.append(self.expect_type(TT.WORD).value)
        return params


def parse(source: str) -> Program:
    from .lexer import tokenize
    tokens = tokenize(source)
    p = Parser(tokens)
    return p.parse()

# ── These are added as methods on the Parser class via monkey-patching ──────
# (Appended here to keep the file manageable)

def _parse_open_window(self, line):
    from .ast_nodes import OpenWindowStatement, StringLiteral, NumberLiteral
    self.advance()  # consume 'open'
    self.match_word('a'); self.match_word('window')
    title = None
    width = None
    height = None
    if self.match_word('titled'):
        title = self.parse_expr()
    if self.match_word('with'):
        # width W, height H  in any order
        while self.peek().type == TT.WORD and self.peek().value in ('width', 'height'):
            key = self.advance().value
            val = self.parse_primary()
            if key == 'width':
                width = val
            else:
                height = val
            if self.peek().type == TT.COMMA:
                self.advance()
    self.expect_period()
    return OpenWindowStatement(title=title, width=width, height=height, line=line)

def _parse_create_widget(self, line):
    from .ast_nodes import CreateWidgetStatement
    self.advance()  # consume 'create'
    self.match_word('a'); self.match_word('an')
    # widget type: label, button, text-input, checkbox, etc.
    wtype_words = []
    while self.peek().type == TT.WORD and self.peek().value not in ('named', 'saying', 'with', 'that'):
        wtype_words.append(self.advance().value)
    widget_type = ' '.join(wtype_words)

    name = ''
    if self.match_word('named'):
        name = self.expect_type(TT.WORD).value

    text = None
    if self.match_word('saying'):
        text = self.parse_expr()

    placeholder = None
    if self.match_word('with'):
        self.match_word('placeholder')
        placeholder = self.parse_expr()

    callback = None
    if self.peek_words('that', 'calls'):
        self.advance(); self.advance()
        callback = self.expect_type(TT.WORD).value

    self.expect_period()
    return CreateWidgetStatement(
        widget_type=widget_type, name=name, text=text,
        callback=callback, placeholder=placeholder, line=line
    )

def _parse_place_in_window(self, line):
    from .ast_nodes import PlaceInWindowStatement
    self.advance()  # consume 'place'
    widgets = [self.expect_type(TT.WORD).value]
    while self.peek().type == TT.COMMA:
        self.advance()
        widgets.append(self.expect_type(TT.WORD).value)
    self.match_word('in'); self.match_word('window')
    self.expect_period()
    return PlaceInWindowStatement(widgets=widgets, line=line)

def _parse_show_window(self, line):
    from .ast_nodes import ShowWindowStatement
    self.advance()  # consume 'show'
    self.match_word('window')
    self.expect_period()
    return ShowWindowStatement(line=line)

def _parse_when(self, line):
    from .ast_nodes import WhenStatement
    self.advance()  # consume 'when'
    widget = self.expect_type(TT.WORD).value
    # event: 'is clicked', 'changes', 'closes'
    event_words = []
    while self.peek().type == TT.WORD and self.peek().value not in ('end',) \
          and self.peek().type != TT.PERIOD:
        event_words.append(self.advance().value)
    event = ' '.join(event_words)
    self.expect_period()
    body = self.parse_block()
    if self.peek_words('end', 'when'):
        self.advance(); self.advance(); self.expect_period()
    return WhenStatement(widget=widget, event=event, body=body, line=line)

# Bind the new methods onto the Parser class
Parser.parse_open_window  = _parse_open_window
Parser.parse_create_widget = _parse_create_widget
Parser.parse_place_in_window = _parse_place_in_window
Parser.parse_show_window   = _parse_show_window
Parser.parse_when          = _parse_when

# ════════════════════════════════════════════════════════════════════════════
# Quill 2.0 — Parser extensions (monkey-patched onto Parser)
# ════════════════════════════════════════════════════════════════════════════

# ── Patch parse_statement to recognise new keywords ─────────────────────────

_orig_parse_statement = Parser.parse_statement

def _new_parse_statement(self, line=None):
    if line is None:
        line = self.current_line()
    t = self.peek()
    if t.type != TT.WORD:
        return _orig_parse_statement(self)
    w = t.value

    # include "file.ql"
    if w == 'include':
        return _parse_include(self, line)

    # set theme to "dark"
    if w == 'set' and self.peek_words('set', 'theme', 'to'):
        self.advance(); self.advance(); self.advance()
        theme = self.parse_expr()
        self.expect_period()
        from .ast_nodes import SetThemeStatement
        return SetThemeStatement(theme=theme, line=line)

    # set color of X to Y
    if w == 'set' and self.peek_words('set', 'color', 'of'):
        self.advance(); self.advance(); self.advance()
        widget = self.expect_type(TT.WORD).value
        self.expect_word('to')
        color = self.parse_expr()
        self.expect_period()
        from .ast_nodes import SetColorStatement
        return SetColorStatement(widget=widget, color=color, line=line)

    # set font size of X to Y
    if w == 'set' and self.peek_words('set', 'font', 'size', 'of'):
        self.advance(); self.advance(); self.advance(); self.advance()
        widget = self.expect_type(TT.WORD).value
        self.expect_word('to')
        size = self.parse_expr()
        self.expect_period()
        from .ast_nodes import SetFontStatement
        return SetFontStatement(widget=widget, size=size, line=line)

    # create a row/column/card layout
    if w == 'create' and self.peek(1).type == TT.WORD and self.peek(1).value in ('a', 'an'):
        wtype2 = self.peek(2).value if self.peek(2).type == TT.WORD else ''
        if wtype2 in ('row', 'column', 'card', 'sidebar', 'tabs', 'tab'):
            return _parse_create_layout(self, line)

    # add X to LAYOUT
    if w == 'add' and _is_add_to_layout(self):
        return _parse_add_to_layout(self, line)

    # show a toast
    if w == 'show' and self.peek_words('show', 'a', 'toast'):
        return _parse_show_toast(self, line)

    # create a chart
    if w == 'create' and self.peek(1).type == TT.WORD and self.peek(1).value in ('a', 'an'):
        wtype3 = self.peek(2).value if self.peek(2).type == TT.WORD else ''
        if wtype3 in ('bar', 'line', 'pie', 'area', 'scatter'):
            return _parse_create_chart(self, line)

    # set data of CHART to LABELS, VALUES
    if w == 'set' and self.peek_words('set', 'data', 'of'):
        return _parse_set_chart_data(self, line)

    # create a table
    if w == 'create' and self.peek(1).type == TT.WORD and self.peek(1).value in ('a', 'an'):
        wtype4 = self.peek(2).value if self.peek(2).type == TT.WORD else ''
        if wtype4 == 'table':
            return _parse_create_table(self, line)

    # add row X to TABLE
    if w == 'add' and self.peek_words('add', 'row'):
        return _parse_add_row(self, line)

    # create a progress bar
    if w == 'create' and self.peek(1).type == TT.WORD and self.peek(1).value in ('a', 'an'):
        wt5 = self.peek(2).value if self.peek(2).type == TT.WORD else ''
        if wt5 == 'progress':
            return _parse_create_progress(self, line)

    # set progress of X to Y
    if w == 'set' and self.peek_words('set', 'progress', 'of'):
        return _parse_set_progress(self, line)

    # create a toggle
    if w == 'create' and self.peek(1).type == TT.WORD and self.peek(1).value in ('a', 'an'):
        wt6 = self.peek(2).value if self.peek(2).type == TT.WORD else ''
        if wt6 == 'toggle':
            return _parse_create_toggle(self, line)

    # create a dropdown
    if w == 'create' and self.peek(1).type == TT.WORD and self.peek(1).value in ('a', 'an'):
        wt7 = self.peek(2).value if self.peek(2).type == TT.WORD else ''
        if wt7 in ('dropdown', 'menu', 'select'):
            return _parse_create_dropdown(self, line)

    # create a slider
    if w == 'create' and self.peek(1).type == TT.WORD and self.peek(1).value in ('a', 'an'):
        wt8 = self.peek(2).value if self.peek(2).type == TT.WORD else ''
        if wt8 == 'slider':
            return _parse_create_slider(self, line)

    # wait N seconds
    if w == 'wait':
        return _parse_wait(self, line)

    # every N seconds call X
    if w == 'every':
        return _parse_every(self, line)

    # connect to database
    if w == 'connect':
        return _parse_sql_connect(self, line)

    # execute SQL on DB
    if w == 'execute':
        return _parse_sql_execute(self, line)

    # write DATA as csv to FILE
    if w == 'write' and _is_csv_write(self):
        return _parse_csv_write(self, line)

    return _orig_parse_statement(self)

Parser.parse_statement = _new_parse_statement


def _is_add_to_layout(parser):
    """Check if 'add X to LAYOUT' where LAYOUT is a known layout keyword."""
    # We can't easily know at parse time, so we intercept in evaluator
    # Just return False here — layout adding is handled by evaluator logic
    return False

def _is_csv_write(parser):
    saved = parser.pos
    try:
        parser.advance()  # write
        parser.parse_expr()
        if parser.peek_words('as', 'csv'):
            return True
    except Exception:
        pass
    finally:
        parser.pos = saved
    return False


# ── New statement parsers ────────────────────────────────────────────────────

def _parse_include(self, line):
    from .ast_nodes import IncludeStatement
    self.advance()  # include
    path = self.parse_expr()
    self.expect_period()
    return IncludeStatement(path=path, line=line)

def _parse_create_layout(self, line):
    from .ast_nodes import CreateLayoutStatement
    self.advance()  # create
    self.match_word('a'); self.match_word('an')
    layout_type = self.expect_type(TT.WORD).value  # row, column, card, tabs
    self.match_word('layout')
    self.match_word('named')
    name = self.expect_type(TT.WORD).value
    title = None
    if self.match_word('titled') or self.match_word('saying'):
        title = self.parse_expr()
    self.expect_period()
    return CreateLayoutStatement(layout_type=layout_type, name=name, title=title, line=line)

def _parse_add_to_layout(self, line):
    from .ast_nodes import AddToLayoutStatement
    self.advance()  # add
    widgets = [self.expect_type(TT.WORD).value]
    while self.peek().type == TT.COMMA:
        self.advance()
        if self.peek().type == TT.WORD and self.peek().value != 'to':
            widgets.append(self.advance().value)
    self.expect_word('to')
    layout = self.expect_type(TT.WORD).value
    self.expect_period()
    return AddToLayoutStatement(widgets=widgets, layout=layout, line=line)

def _parse_show_toast(self, line):
    from .ast_nodes import ShowToastStatement
    self.advance(); self.advance(); self.advance()  # show a toast
    self.match_word('saying')
    msg = self.parse_expr()
    duration = None
    if self.match_word('for'):
        duration = self.parse_expr()
        self.match_word('seconds')
    self.expect_period()
    return ShowToastStatement(message=msg, duration=duration, line=line)

def _parse_create_chart(self, line):
    from .ast_nodes import CreateChartStatement
    self.advance()  # create
    self.match_word('a'); self.match_word('an')
    chart_type = self.expect_type(TT.WORD).value  # bar, line, pie
    self.match_word('chart')
    self.match_word('named')
    name = self.expect_type(TT.WORD).value
    title = None
    if self.match_word('titled') or self.match_word('saying'):
        title = self.parse_expr()
    self.expect_period()
    return CreateChartStatement(chart_type=chart_type, name=name, title=title, line=line)

def _parse_set_chart_data(self, line):
    from .ast_nodes import SetChartDataStatement
    self.advance(); self.advance(); self.advance()  # set data of
    chart = self.expect_type(TT.WORD).value
    self.expect_word('to')
    labels = self.parse_expr()
    values = None
    if self.peek().type == TT.COMMA:
        self.advance()
        values = self.parse_expr()
    self.expect_period()
    return SetChartDataStatement(chart=chart, labels=labels, values=values, line=line)

def _parse_create_table(self, line):
    from .ast_nodes import CreateTableStatement
    self.advance(); self.match_word('a'); self.match_word('an')
    self.expect_word('table')
    self.match_word('named')
    name = self.expect_type(TT.WORD).value
    columns = []
    if self.match_word('with'):
        self.match_word('columns')
        columns = self.parse_expr_list()
    self.expect_period()
    return CreateTableStatement(name=name, columns=columns, line=line)

def _parse_add_row(self, line):
    from .ast_nodes import AddRowStatement
    self.advance(); self.advance()  # add row
    values = self.parse_expr_list()
    self.expect_word('to')
    table = self.expect_type(TT.WORD).value
    self.expect_period()
    return AddRowStatement(values=values, table=table, line=line)

def _parse_create_progress(self, line):
    from .ast_nodes import CreateProgressStatement
    self.advance(); self.match_word('a'); self.match_word('an')
    self.expect_word('progress')
    self.match_word('bar')
    self.match_word('named')
    name = self.expect_type(TT.WORD).value
    self.expect_period()
    return CreateProgressStatement(name=name, line=line)

def _parse_set_progress(self, line):
    from .ast_nodes import SetProgressStatement
    self.advance(); self.advance(); self.advance()  # set progress of
    name = self.expect_type(TT.WORD).value
    self.expect_word('to')
    value = self.parse_expr()
    self.expect_period()
    return SetProgressStatement(name=name, value=value, line=line)

def _parse_create_toggle(self, line):
    from .ast_nodes import CreateToggleStatement
    self.advance(); self.match_word('a'); self.match_word('an')
    self.expect_word('toggle')
    self.match_word('named')
    name = self.expect_type(TT.WORD).value
    text = None
    if self.match_word('saying'):
        text = self.parse_expr()
    self.expect_period()
    return CreateToggleStatement(name=name, text=text, line=line)

def _parse_create_dropdown(self, line):
    from .ast_nodes import CreateDropdownStatement
    self.advance(); self.match_word('a'); self.match_word('an')
    self.advance()  # dropdown/menu/select
    self.match_word('named')
    name = self.expect_type(TT.WORD).value
    choices = []
    if self.match_word('with'):
        self.match_word('choices')
        choices = self.parse_expr_list()
    self.expect_period()
    return CreateDropdownStatement(name=name, choices=choices, line=line)

def _parse_create_slider(self, line):
    from .ast_nodes import CreateSliderStatement
    self.advance(); self.match_word('a'); self.match_word('an')
    self.expect_word('slider')
    self.match_word('named')
    name = self.expect_type(TT.WORD).value
    min_val = None; max_val = None
    if self.match_word('from'):
        min_val = self.parse_primary()
        self.expect_word('to')
        max_val = self.parse_primary()
    self.expect_period()
    return CreateSliderStatement(name=name, min_val=min_val, max_val=max_val, line=line)

def _parse_wait(self, line):
    from .ast_nodes import WaitStatement
    self.advance()  # wait
    duration = self.parse_primary()
    self.match_word('seconds'); self.match_word('second')
    self.expect_period()
    return WaitStatement(duration=duration, line=line)

def _parse_every(self, line):
    from .ast_nodes import EveryStatement
    self.advance()  # every
    interval = self.parse_primary()
    self.match_word('seconds'); self.match_word('second')
    self.match_word('call')
    callback = self.expect_type(TT.WORD).value
    self.expect_period()
    return EveryStatement(interval=interval, callback=callback, line=line)

def _parse_sql_connect(self, line):
    from .ast_nodes import SqlConnectStatement
    self.advance()  # connect
    self.match_word('to')
    self.match_word('database')
    path = self.parse_expr()
    alias = 'db'
    if self.match_word('as'):
        alias = self.expect_type(TT.WORD).value
    self.expect_period()
    return SqlConnectStatement(path=path, alias=alias, line=line)

def _parse_sql_execute(self, line):
    from .ast_nodes import SqlExecuteStatement
    self.advance()  # execute
    sql = self.parse_expr()
    self.match_word('on')
    db = self.expect_type(TT.WORD).value
    params = None
    if self.match_word('with'):
        params = self.parse_expr()
    self.expect_period()
    return SqlExecuteStatement(db=db, sql=sql, params=params, line=line)

def _parse_csv_write(self, line):
    from .ast_nodes import CsvWriteStatement
    self.advance()  # write
    data = self.parse_expr()
    self.expect_word('as'); self.expect_word('csv')
    self.expect_word('to')
    self.match_word('file')
    path = self.parse_expr()
    self.expect_period()
    return CsvWriteStatement(data=data, path=path, line=line)


# ── New expression forms in parse_primary ────────────────────────────────────

_orig_parse_primary = Parser.parse_primary

def _new_parse_primary(self):
    t = self.peek()
    line = t.line
    if t.type == TT.WORD:
        w = t.value

        # get EXPR — HTTP GET (accepts variable or string literal)
        if w == 'get' and self.peek(1).type in (TT.STRING, TT.WORD):
            # Make sure it's not 'get' as a variable name by checking context
            # If next token is a string, it's definitely an HTTP get
            # If next token is a word, only treat as HTTP get if it looks like a URL variable
            next_t = self.peek(1)
            is_http = (next_t.type == TT.STRING or 
                       (next_t.type == TT.WORD and next_t.value not in 
                        ('from', 'in', 'into', 'on', 'at', 'of', 'to', 'a', 'an', 'the')))
            if is_http:
                self.advance()
                url = self.parse_primary()
                from .ast_nodes import HttpGetExpr
                return HttpGetExpr(url=url, line=line)

        # post to "url" with DATA
        if w == 'post' and self.peek_words('post', 'to'):
            self.advance(); self.advance()
            url = self.parse_primary()
            data = None
            if self.match_word('with'):
                data = self.parse_expr()
            from .ast_nodes import HttpPostExpr
            return HttpPostExpr(url=url, data=data, line=line)

        # read csv "file"
        if w == 'read' and self.peek_words('read', 'csv'):
            self.advance(); self.advance()
            self.match_word('file')
            path = self.parse_primary()
            from .ast_nodes import CsvReadExpr
            return CsvReadExpr(path=path, line=line)

        # query DB with "SQL"
        if w == 'query':
            self.advance()
            db = self.expect_type(TT.WORD).value
            self.match_word('with')
            sql = self.parse_primary()
            from .ast_nodes import SqlQueryExpr
            return SqlQueryExpr(db=db, sql=sql, line=line)

        # the maximum of LIST
        if w == 'the' and self.peek_words('the', 'maximum', 'of'):
            self.advance(); self.advance(); self.advance()
            from .ast_nodes import MaxOfExpr
            return MaxOfExpr(target=self.parse_primary(), line=line)

        if w == 'the' and self.peek_words('the', 'minimum', 'of'):
            self.advance(); self.advance(); self.advance()
            from .ast_nodes import MinOfExpr
            return MinOfExpr(target=self.parse_primary(), line=line)

        if w == 'the' and self.peek_words('the', 'sum', 'of'):
            self.advance(); self.advance(); self.advance()
            from .ast_nodes import SumOfExpr
            return SumOfExpr(target=self.parse_primary(), line=line)

        # items in LIST where VAR CONDITION
        if w == 'items' and self.peek_words('items', 'in'):
            self.advance(); self.advance()
            target = self.parse_primary()
            self.expect_word('where')
            var = self.expect_type(TT.WORD).value
            condition = self.parse_condition()
            from .ast_nodes import FilteredExpr
            return FilteredExpr(target=target, variable=var, condition=condition, line=line)

        # LIST sorted by KEY
        # handled as postfix — fall through to original

    # Delegate to original
    node = _orig_parse_primary(self)

    # Add new postfix forms
    while True:
        if self.peek_words('sorted', 'by'):
            self.advance(); self.advance()
            key = self.expect_type(TT.WORD).value
            desc = self.match_word('descending')
            from .ast_nodes import SortedExpr
            node = SortedExpr(target=node, key=key, descending=desc, line=node.line)
        elif self.peek_words('sorted', 'descending'):
            self.advance(); self.advance()
            from .ast_nodes import SortedExpr
            node = SortedExpr(target=node, key=None, descending=True, line=node.line)
        elif self.peek_words('joined', 'by'):
            self.advance(); self.advance()
            sep = self.parse_primary()
            from .ast_nodes import JoinedListExpr
            node = JoinedListExpr(target=node, separator=sep, line=node.line)
        else:
            break

    return node

Parser.parse_primary = _new_parse_primary


# Patch parse_show_window to also recognise 'show window.'
def _parse_show_window_v2(self, line):
    from .ast_nodes import ShowWindowStatement
    self.advance()  # 'show'
    self.match_word('window')
    self.expect_period()
    return ShowWindowStatement(line=line)

Parser.parse_show_window = _parse_show_window_v2


# Bind all new parser methods
Parser._parse_include          = _parse_include
Parser._parse_create_layout    = _parse_create_layout
Parser._parse_add_to_layout    = _parse_add_to_layout
Parser._parse_show_toast       = _parse_show_toast
Parser._parse_create_chart     = _parse_create_chart
Parser._parse_set_chart_data   = _parse_set_chart_data
Parser._parse_create_table     = _parse_create_table
Parser._parse_add_row          = _parse_add_row
Parser._parse_create_progress  = _parse_create_progress
Parser._parse_set_progress     = _parse_set_progress
Parser._parse_create_toggle    = _parse_create_toggle
Parser._parse_create_dropdown  = _parse_create_dropdown
Parser._parse_create_slider    = _parse_create_slider
Parser._parse_wait             = _parse_wait
Parser._parse_every            = _parse_every
Parser._parse_sql_connect      = _parse_sql_connect
Parser._parse_sql_execute      = _parse_sql_execute
Parser._parse_csv_write        = _parse_csv_write
