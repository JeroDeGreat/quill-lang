"""
Quill Lexer — Tokenizes .ql source into a flat token stream.

Token types  : WORD | STRING | NUMBER | DECIMAL | COMMA | PERIOD | INDENT | DEDENT | NEWLINE | EOF
Keywords and multi-word constructs are resolved by the parser from WORD sequences.
"""
from __future__ import annotations
from dataclasses import dataclass
from enum import Enum, auto
from typing import List


class TT(Enum):
    WORD    = auto()
    STRING  = auto()
    NUMBER  = auto()
    DECIMAL = auto()
    COMMA   = auto()
    PERIOD  = auto()
    INDENT  = auto()
    DEDENT  = auto()
    NEWLINE = auto()
    EOF     = auto()


@dataclass
class Token:
    type: TT
    value: object
    line: int
    col: int

    def __repr__(self):
        return f"Token({self.type.name}, {self.value!r}, L{self.line})"


class LexError(Exception):
    def __init__(self, msg, line, col=0):
        super().__init__(f"Line {line}: {msg}")
        self.line = line
        self.col = col


def tokenize(source: str) -> List[Token]:
    """
    Main entry point.  Returns a flat list of Tokens ending with EOF.
    """
    tokens: List[Token] = []
    indent_stack: List[int] = [0]

    # ── Pre-process: strip multi-line comments ───────────────────────────
    source = _strip_block_comments(source)

    lines = source.splitlines()
    in_block_comment = False

    for line_no, raw_line in enumerate(lines, start=1):
        # Inline "note" comment: remove from "note" to end-of-line
        processed = _strip_inline_note(raw_line)
        if processed is None:
            # Entire line is a note comment
            continue

        stripped = processed.rstrip()
        if not stripped.strip():
            # Blank / whitespace-only line
            continue

        # ── Measure indentation ──────────────────────────────────────────
        indent = 0
        for ch in stripped:
            if ch == ' ':
                indent += 1
            elif ch == '\t':
                indent += 4
            else:
                break

        current = indent_stack[-1]
        if indent > current:
            indent_stack.append(indent)
            tokens.append(Token(TT.INDENT, indent, line_no, 1))
        else:
            while len(indent_stack) > 1 and indent_stack[-1] > indent:
                indent_stack.pop()
                tokens.append(Token(TT.DEDENT, indent_stack[-1], line_no, 1))

        # ── Tokenize non-whitespace content ─────────────────────────────
        _tokenize_line(stripped, line_no, tokens)

        tokens.append(Token(TT.NEWLINE, '\n', line_no, len(stripped) + 1))

    # Emit remaining DEDENTs
    while len(indent_stack) > 1:
        indent_stack.pop()
        tokens.append(Token(TT.DEDENT, 0, len(lines), 1))

    tokens.append(Token(TT.EOF, None, len(lines) + 1, 1))
    return tokens


# ─── Helpers ────────────────────────────────────────────────────────────────

def _strip_block_comments(source: str) -> str:
    """Remove begin note. ... end note. blocks."""
    import re
    # Case-insensitive, dotall
    pattern = re.compile(r'begin\s+note\s*\..*?end\s+note\s*\.', re.IGNORECASE | re.DOTALL)
    return pattern.sub('', source)


def _strip_inline_note(line: str) -> str | None:
    """
    If the non-whitespace content starts with 'note' or 'note:',
    return None (skip whole line).  Otherwise return the line with
    any mid-line note stripped (we don't support mid-line notes per spec,
    but being lenient is fine).
    """
    stripped = line.lstrip()
    lower = stripped.lower()
    if lower.startswith('note:') or lower.startswith('note ') or lower == 'note':
        return None
    return line


def _tokenize_line(line: str, line_no: int, tokens: List[Token]):
    pos = 0
    n = len(line)

    while pos < n:
        ch = line[pos]

        # ── Whitespace ───────────────────────────────────────────────────
        if ch in ' \t':
            pos += 1
            continue

        # ── String literal ────────────────────────────────────────────────
        if ch == '"':
            start_col = pos + 1
            pos += 1
            buf: List[str] = []
            while pos < n:
                c = line[pos]
                if c == '"':
                    pos += 1
                    break
                if c == '\\' and pos + 1 < n:
                    pos += 1
                    esc = line[pos]
                    buf.append({'n': '\n', 't': '\t', '"': '"', '\\': '\\'}.get(esc, esc))
                    pos += 1
                else:
                    buf.append(c)
                    pos += 1
            else:
                raise LexError("Unterminated string literal", line_no)
            tokens.append(Token(TT.STRING, ''.join(buf), line_no, start_col))
            continue

        # ── Number ────────────────────────────────────────────────────────
        if ch.isdigit():
            start = pos
            while pos < n and line[pos].isdigit():
                pos += 1
            # Decimal?
            if pos < n and line[pos] == '.' and pos + 1 < n and line[pos + 1].isdigit():
                pos += 1  # consume '.'
                while pos < n and line[pos].isdigit():
                    pos += 1
                tokens.append(Token(TT.DECIMAL, float(line[start:pos]), line_no, start + 1))
            else:
                tokens.append(Token(TT.NUMBER, int(line[start:pos]), line_no, start + 1))
            continue

        # ── Comma ─────────────────────────────────────────────────────────
        if ch == ',':
            tokens.append(Token(TT.COMMA, ',', line_no, pos + 1))
            pos += 1
            continue

        # ── Period (statement terminator) ─────────────────────────────────
        if ch == '.':
            tokens.append(Token(TT.PERIOD, '.', line_no, pos + 1))
            pos += 1
            continue

        # ── Word / identifier ─────────────────────────────────────────────
        if ch.isalpha() or ch == '_':
            start = pos
            while pos < n and (line[pos].isalnum() or line[pos] in '_-'):
                pos += 1
            word = line[start:pos].lower()
            tokens.append(Token(TT.WORD, word, line_no, start + 1))
            continue

        # ── Unknown character — skip (Quill disallows symbols anyway) ────
        pos += 1
