"""Quill error types with plain-English messages."""

class QuillError(Exception):
    def __init__(self, message, line=None):
        self.quill_message = message
        self.line = line
        super().__init__(message)

    def __str__(self):
        if self.line:
            return f"Error on line {self.line}: {self.quill_message}"
        return f"Error: {self.quill_message}"


class QuillSyntaxError(QuillError):
    pass


class QuillRuntimeError(QuillError):
    pass


class QuillNameError(QuillRuntimeError):
    pass


class QuillTypeError(QuillRuntimeError):
    pass


# Control flow signals (not really errors)
class ReturnSignal(Exception):
    def __init__(self, value):
        self.value = value

class BreakSignal(Exception):
    pass

class ContinueSignal(Exception):
    pass
