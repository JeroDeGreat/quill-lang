"""
Quill Programming Language
"Write code the way you think."
"""
__version__ = "2.0.0"
__author__ = "Quill Language Team"

from .evaluator import run_string
from .parser import parse
from .lexer import tokenize

def run_file(path: str):
    """Run a .ql file."""
    with open(path, 'r', encoding='utf-8') as f:
        source = f.read()
    return run_string(source)
