"""
Quill REPL — interactive read-eval-print loop.
"""

import sys
import readline  # noqa: F401 (enables arrow-key history on Unix)
from .evaluator import Evaluator, Environment
from .lexer import tokenize
from .parser import parse
from .errors import QuillError

BANNER = r"""
  ____        _ _ _ 
 / __ \      (_) | |
| |  | |_   _ _| | |
| |  | | | | | | | |
| |__| | |_| | | | |
 \___\_\\__,_|_|_|_|

  Write code the way you think.
  Type 'exit.' or 'quit.' to leave.
  Type 'help.' for a quick reference.
"""

HELP_TEXT = """
Quick Quill Reference
─────────────────────
  let name be "Alice".            Declare a variable
  set name to "Bob".              Reassign a variable
  say "Hello, {name}!".           Print with interpolation
  ask "Your name?" into name.     Read input

  if age is greater than 17.      Conditional
    say "Adult.".
  end if.

  repeat 5 times.                 Loop 5 times
    say "Hello!".
  end repeat.

  define greet taking name.       Define a function
    say "Hi, {name}!".
  end define.
  greet with "Alice".

  let nums be a list of 1, 2, 3. Lists
  add 4 to nums.

Type any Quill statement and press Enter to run it.
Multi-line blocks are detected automatically.
"""

# Keywords that open a block (we wait for 'end X.' before running)
BLOCK_OPENERS = {'if', 'repeat', 'while', 'for', 'define', 'try', 'class',
                 'begin note', 'run python', 'run javascript'}
BLOCK_CLOSERS = {'end if', 'end repeat', 'end while', 'end for', 'end define',
                 'end try', 'end class', 'end note', 'end python', 'end javascript'}


def _count_open_blocks(lines):
    """Return number of unclosed block openers in the given line list."""
    depth = 0
    for line in lines:
        stripped = line.strip().lower().rstrip('.')
        for opener in BLOCK_OPENERS:
            if stripped == opener or stripped.startswith(opener + ' '):
                depth += 1
                break
        for closer in BLOCK_CLOSERS:
            if stripped == closer or stripped.startswith(closer):
                depth -= 1
                break
    return max(depth, 0)


def run_repl():
    print(BANNER)
    ev = Evaluator()
    buffer = []

    while True:
        prompt = 'quill> ' if not buffer else '  ...  '
        try:
            line = input(prompt)
        except (EOFError, KeyboardInterrupt):
            print('\nGoodbye!')
            break

        stripped = line.strip().lower().rstrip('.')
        if stripped in ('exit', 'quit'):
            print('Goodbye!')
            break
        if stripped == 'help':
            print(HELP_TEXT)
            buffer = []
            continue

        buffer.append(line)
        open_blocks = _count_open_blocks(buffer)

        if open_blocks > 0:
            continue  # wait for more input

        source = '\n'.join(buffer)
        buffer = []

        if not source.strip():
            continue

        try:
            tokens = tokenize(source, '<repl>')
            ast = parse(tokens, '<repl>')
            result = ev.evaluate(ast)
            # Auto-print expression results
            if result is not None:
                print(f'=> {ev._to_display(result)}')
        except QuillError as e:
            print(f'\n{e}\n')
        except Exception as e:
            print(f'\nInternal error: {e}\n')
