"""
Quill stdlib — data module.
Provides CSV, statistics, filtering, sorting without external dependencies.
Loaded by: use data.
"""
import csv, statistics, json, os


def register(env):
    """Register all data functions into the Quill environment."""

    def read_csv(path):
        rows = []
        with open(str(path), 'r', encoding='utf-8', newline='') as f:
            reader = csv.DictReader(f)
            for row in reader:
                rows.append(dict(row))
        return rows

    def write_csv_data(data, path):
        if not data:
            return
        with open(str(path), 'w', encoding='utf-8', newline='') as f:
            if isinstance(data[0], dict):
                writer = csv.DictWriter(f, fieldnames=list(data[0].keys()))
                writer.writeheader()
                writer.writerows(data)
            else:
                writer = csv.writer(f)
                writer.writerows(data)

    def filter_rows(rows, key, value):
        return [r for r in rows if str(r.get(key, '')) == str(value)]

    def sort_rows(rows, key, reverse=False):
        def safe_key(r):
            v = r.get(key, '')
            try:
                return float(v)
            except (ValueError, TypeError):
                return str(v)
        return sorted(rows, key=safe_key, reverse=bool(reverse))

    def column_values(rows, key):
        return [r.get(key) for r in rows if key in r]

    def unique_values(lst):
        seen = []
        for v in lst:
            if v not in seen:
                seen.append(v)
        return seen

    def count_by(rows, key):
        counts = {}
        for r in rows:
            v = str(r.get(key, 'unknown'))
            counts[v] = counts.get(v, 0) + 1
        return counts

    def average(lst):
        nums = [float(x) for x in lst if x is not None]
        return sum(nums) / len(nums) if nums else 0

    def median_val(lst):
        nums = sorted([float(x) for x in lst if x is not None])
        if not nums:
            return 0
        n = len(nums)
        if n % 2 == 0:
            return (nums[n//2-1] + nums[n//2]) / 2
        return nums[n//2]

    def std_dev(lst):
        nums = [float(x) for x in lst if x is not None]
        if len(nums) < 2:
            return 0
        mean = sum(nums) / len(nums)
        variance = sum((x - mean) ** 2 for x in nums) / len(nums)
        return variance ** 0.5

    def percentile(lst, p):
        nums = sorted([float(x) for x in lst if x is not None])
        if not nums:
            return 0
        idx = (float(p) / 100) * (len(nums) - 1)
        lo, hi = int(idx), min(int(idx) + 1, len(nums) - 1)
        return nums[lo] + (nums[hi] - nums[lo]) * (idx - lo)

    def normalize(lst):
        nums = [float(x) for x in lst]
        mn, mx = min(nums), max(nums)
        rng = mx - mn
        if rng == 0:
            return [0.0] * len(nums)
        return [(x - mn) / rng for x in nums]

    def group_by(rows, key):
        groups = {}
        for r in rows:
            v = str(r.get(key, 'other'))
            if v not in groups:
                groups[v] = []
            groups[v].append(r)
        return groups

    def head(lst, n=5):
        return lst[:int(n)]

    def tail(lst, n=5):
        return lst[-int(n):]

    def flatten(lst):
        result = []
        for item in lst:
            if isinstance(item, list):
                result.extend(item)
            else:
                result.append(item)
        return result

    def zip_lists(a, b):
        return [{'first': x, 'second': y} for x, y in zip(a, b)]

    env.define('read csv',        read_csv)
    env.define('write csv',       write_csv_data)
    env.define('filter rows',     filter_rows)
    env.define('sort rows',       sort_rows)
    env.define('column values',   column_values)
    env.define('unique values',   unique_values)
    env.define('count by',        count_by)
    env.define('average of',      average)
    env.define('median of',       median_val)
    env.define('std dev of',      std_dev)
    env.define('percentile of',   percentile)
    env.define('normalize',       normalize)
    env.define('group by',        group_by)
    env.define('head of',         head)
    env.define('tail of',         tail)
    env.define('flatten',         flatten)
    env.define('zip lists',       zip_lists)


def register_aliases(env):
    """Register single-word aliases."""
    try:
        env.define('readcsv',     env.get('read csv'))
        env.define('writecsv',    env.get('write csv'))
        env.define('filterrows',  env.get('filter rows'))
        env.define('sortrows',    env.get('sort rows'))
        env.define('columnvals',  env.get('column values'))
        env.define('unique',      env.get('unique values'))
        env.define('countby',     env.get('count by'))
        env.define('average',     env.get('average of'))
        env.define('median',      env.get('median of'))
        env.define('stddev',      env.get('std dev of'))
        env.define('percentile',  env.get('percentile of'))
        env.define('normalize',   env.get('normalize'))
        env.define('groupby',     env.get('group by'))
        env.define('head',        env.get('head of'))
        env.define('tail',        env.get('tail of'))
        env.define('flatten',     env.get('flatten'))
    except Exception:
        pass
