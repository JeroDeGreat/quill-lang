"""
Quill Standard Library module loader.
"""

MODULE_REGISTRY = {
    'data':       'quill.stdlib.data',
    'ml':         'quill.stdlib.ml',
    'crypto':     'quill.stdlib.crypto_mod',
    'net':        'quill.stdlib.net',
    'server':     'quill.stdlib.web_server',
    'blockchain': 'quill.stdlib.blockchain',
}


def load_module(name: str, env, evaluator=None):
    import importlib
    module_path = MODULE_REGISTRY.get(name.lower())
    if not module_path:
        return False
    try:
        mod = importlib.import_module(module_path)
        if hasattr(mod, '_evaluator_ref') and evaluator:
            mod._evaluator_ref = evaluator
        mod.register(env)
        # Register single-word aliases if available
        if hasattr(mod, 'register_aliases'):
            try:
                mod.register_aliases(env)
            except Exception:
                pass
        return True
    except Exception as e:
        print(f"Warning: Could not load stdlib module '{name}': {e}")
        return False
