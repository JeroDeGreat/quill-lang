"""
Quill stdlib — net module.
Networking utilities: DNS, ping, port scanning, TCP connections.
Loaded by: use net.
"""
import socket, urllib.request, urllib.parse, json as _json
import time


def register(env):

    def dns_lookup(hostname):
        """Resolve hostname to IP."""
        try:
            return socket.gethostbyname(str(hostname))
        except socket.gaierror as e:
            return f'DNS error: {e}'

    def reverse_dns(ip):
        """Reverse DNS lookup."""
        try:
            return socket.gethostbyaddr(str(ip))[0]
        except Exception as e:
            return f'Error: {e}'

    def is_port_open(host, port, timeout=2):
        """Check if a TCP port is open."""
        try:
            sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            sock.settimeout(float(timeout))
            result = sock.connect_ex((str(host), int(port)))
            sock.close()
            return result == 0
        except Exception:
            return False

    def scan_ports(host, start_port=1, end_port=1024, timeout=0.5):
        """Scan a range of ports. Returns list of open ports."""
        open_ports = []
        for port in range(int(start_port), int(end_port) + 1):
            if is_port_open(host, port, timeout):
                open_ports.append(port)
        return open_ports

    def get_my_ip():
        """Get local machine IP."""
        try:
            with socket.socket(socket.AF_INET, socket.SOCK_DGRAM) as s:
                s.connect(('8.8.8.8', 80))
                return s.getsockname()[0]
        except Exception:
            return '127.0.0.1'

    def get_public_ip():
        """Get public IP via API."""
        try:
            req = urllib.request.Request('https://api.ipify.org')
            with urllib.request.urlopen(req, timeout=5) as resp:
                return resp.read().decode('utf-8').strip()
        except Exception as e:
            return f'Error: {e}'

    def http_get(url, headers=None):
        """Simple HTTP GET."""
        try:
            req = urllib.request.Request(str(url))
            req.add_header('User-Agent', 'QuillLang/2.0')
            if isinstance(headers, dict):
                for k, v in headers.items():
                    req.add_header(str(k), str(v))
            with urllib.request.urlopen(req, timeout=10) as resp:
                return {
                    'status': resp.status,
                    'body': resp.read().decode('utf-8'),
                    'headers': dict(resp.getheaders()),
                }
        except Exception as e:
            return {'status': 0, 'body': str(e), 'headers': {}}

    def whois_lookup(domain):
        """Basic WHOIS via an API."""
        try:
            url = f'https://api.whois.vu/?q={urllib.parse.quote(str(domain))}'
            req = urllib.request.Request(url)
            req.add_header('User-Agent', 'QuillLang/2.0')
            with urllib.request.urlopen(req, timeout=8) as resp:
                return resp.read().decode('utf-8')
        except Exception as e:
            return f'WHOIS error: {e}'

    def tcp_send(host, port, message):
        """Send a message over TCP and return response."""
        try:
            with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
                s.settimeout(5)
                s.connect((str(host), int(port)))
                s.sendall(str(message).encode('utf-8'))
                data = s.recv(4096)
                return data.decode('utf-8')
        except Exception as e:
            return f'TCP error: {e}'

    def url_encode(text):
        return urllib.parse.quote(str(text))

    def url_decode(text):
        return urllib.parse.unquote(str(text))

    def parse_url(url):
        parsed = urllib.parse.urlparse(str(url))
        return {
            'scheme': parsed.scheme,
            'host': parsed.netloc,
            'path': parsed.path,
            'query': parsed.query,
            'fragment': parsed.fragment,
        }

    env.define('dns lookup',   dns_lookup)
    env.define('reverse dns',  reverse_dns)
    env.define('is port open', is_port_open)
    env.define('scan ports',   scan_ports)
    env.define('my ip',        get_my_ip())
    env.define('get public ip',get_public_ip)
    env.define('http get',     http_get)
    env.define('whois',        whois_lookup)
    env.define('tcp send',     tcp_send)
    env.define('url encode',   url_encode)
    env.define('url decode',   url_decode)
    env.define('parse url',    parse_url)



def register_aliases(env):
    """Register single-word aliases."""
    try:
        env.define('dnslookup',   env.get('dns lookup'))
        env.define('reversedns',  env.get('reverse dns'))
        env.define('isportopen',  env.get('is port open'))
        env.define('scanports',   env.get('scan ports'))
        env.define('publicip',    env.get('get public ip'))
        env.define('urlparse',    env.get('parse url'))
        env.define('urlencode',   env.get('url encode'))
        env.define('urldecode',   env.get('url decode'))
        env.define('tcpsend',     env.get('tcp send'))
    except Exception:
        pass
