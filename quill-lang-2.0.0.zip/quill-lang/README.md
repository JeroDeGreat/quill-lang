<div align="center">

<img src="quill-icon.svg" width="120" alt="Quill Logo"/>

# 🪶 Quill Programming Language

### *"Write code the way you think."*

**The world's most readable programming language. If you can speak English, you can write Quill.**

[![Version](https://img.shields.io/badge/version-2.0.0-blue?style=flat-square)](https://github.com/quill-lang/quill)
[![License](https://img.shields.io/badge/license-MIT-green?style=flat-square)](LICENSE)
[![Python](https://img.shields.io/badge/python-3.10+-yellow?style=flat-square)](https://python.org)
[![Platform](https://img.shields.io/badge/platform-Windows%20%7C%20Linux%20%7C%20macOS-lightgrey?style=flat-square)]()

**Created by Jero W. Grabo · Quill Language Team**

[Download](#installation) · [Documentation](docs/LANGUAGE_REFERENCE.md) · [Examples](examples/) · [Website](https://quill-lang.org)

</div>

---

## What is Quill?

Quill is a fully functional programming language where every line reads like a plain English sentence.
The **only** punctuation characters in Quill are the **comma** `,` and the **period** `.`

```quill
let name be "Alice".
let age be 28.

if age is at least 18.
  say "Welcome, {name}! You are an adult.".
else.
  say "Sorry, {name}. Come back when you're older.".
end if.
```

No braces. No semicolons. No `->` or `=>`. No `$`, `#`, `@`, `!`, `%`, `^`, `&`, `*`, `(`, `)`, `[`, `]`, `{`, `}`. Just English.

---

## What Can Quill Do?

| Field | What you can build |
|---|---|
| 🤖 **AI & Machine Learning** | Classifiers, regression, clustering, data pipelines |
| 📊 **Data Science** | CSV analysis, statistics, visualization, reporting |
| 🖥️ **Desktop Apps** | Professional GUI apps with dark mode, charts, tables |
| 🌐 **Web Development** | HTTP servers, REST API clients, JSON processing |
| 🔒 **Cybersecurity** | Password managers, hash tools, port scanners, crypto |
| 🗄️ **Databases** | SQLite CRUD apps, data persistence |
| ⚡ **Scripting & Automation** | File organizers, system scripts, batch processing |
| 🌍 **Networking** | DNS lookup, port scanning, TCP clients |
| ⛓️ **Blockchain** | Educational blockchain implementations |
| 🎮 **Games** | Terminal games, interactive quizzes |
| 🔗 **Python Interop** | Use any Python library from Quill |

---

## Installation

### 🪟 Windows

**Option A — Recommended (from the zip)**

1. Download `quill-lang-2.0.0.zip` from the releases page
2. Extract it to `C:\Users\YourName\Downloads\quill-lang`
3. Open PowerShell (`Win+X` → Terminal)
4. Navigate to the folder:
   ```powershell
   cd "C:\Users\YourName\Downloads\quill-lang"
   ```
5. Run the installer:
   ```powershell
   powershell -ExecutionPolicy Bypass -File ".\install.ps1"
   ```
6. Close PowerShell, open a **new** terminal
7. Verify: `quill version`

**Option B — pip**
```powershell
pip install quill-lang
```

**Troubleshooting Windows:**

| Problem | Solution |
|---|---|
| `quill is not recognized` | Close terminal and open a new one. If still failing, log out and back in. |
| `Script cannot be loaded` | Run: `Set-ExecutionPolicy -Scope CurrentUser RemoteSigned` then retry |
| `The file is not digitally signed` | Use: `powershell -ExecutionPolicy Bypass -File ".\install.ps1"` |
| `Cannot find Python` | Install Python from python.org — **tick "Add Python to PATH" on the first screen** |
| `Jero Grabo in path errors` | Spaces in username break unquoted paths — always quote paths in PowerShell |
| `Too early to create variable` | GUI bug — reinstall from latest zip which fixes this |
| Path has quotes doubled (`""path""`) | Remove the quotes from your VS Code settings — the extension adds its own |

---

### 🐧 Linux

**Ubuntu / Debian / Kali:**
```bash
curl -sSL https://quill-lang.org/install.sh | bash
```

Or from the zip:
```bash
cd ~/Downloads/quill-lang
chmod +x install.sh
./install.sh
source ~/.bashrc
quill version
```

**Kali Linux (optimized):**
```bash
sudo apt update
sudo apt install python3 python3-pip python3-tk -y
pip3 install quill-lang customtkinter matplotlib
```

**Troubleshooting Linux:**

| Problem | Solution |
|---|---|
| `quill: command not found` | Run `source ~/.bashrc` or restart terminal |
| `No module named tkinter` | `sudo apt install python3-tk` |
| `No module named pip` | `sudo apt install python3-pip` |
| Permission denied on install.sh | `chmod +x install.sh` then `./install.sh` |
| Script runs but GUI won't open | `sudo apt install python3-tk python3-dev` |
| customtkinter not found | `pip3 install customtkinter` |

---

### 🍎 macOS

```bash
curl -sSL https://quill-lang.org/install.sh | bash
source ~/.zshrc
quill version
```

Or with Homebrew:
```bash
brew install python@3.12
pip3 install quill-lang customtkinter matplotlib
```

**Troubleshooting macOS:**

| Problem | Solution |
|---|---|
| `quill: command not found` | Run `source ~/.zshrc` (or `~/.bash_profile` if using bash) |
| GUI app shows blank window | Install `python-tk@3.12` via Homebrew |
| SSL certificate errors | Run: `pip3 install certifi` |

---

## Quick Start

```bash
quill version               # Check version
quill repl                  # Interactive REPL
quill new myproject         # Create a new project
quill run myfile.ql         # Run a program
quill run myfile.ql --debug # Debug mode (shows AST)
quill check myfile.ql       # Check syntax only
quill build myfile.ql       # Build standalone executable
quill help                  # Show all commands
```

---

## VS Code Extension

Install for syntax highlighting, IntelliSense, and the run button:

1. Open VS Code
2. Press `Ctrl+Shift+P`
3. Type `Install from VSIX` → press Enter
4. Select `quill-lang.vsix` from the quill-lang folder
5. Click Reload

**Configure the executable path:**
- Press `Ctrl+,` → search for `quill`
- Set **Quill: Executable Path** to: `C:\Users\YourName\AppData\Roaming\Quill\bin\quill.bat`
- Do **not** include quotes in the settings box

---

## Language at a Glance

```quill
note Variables
let name be "Alice".
let age be 25.
let score be 9.99.
let active be yes.

note Arithmetic (English words only)
let total be price times quantity.
let half be total divided by 2.
let remainder be total mod 7.

note Conditions
if age is at least 18.
  say "Adult.".
else.
  say "Minor.".
end if.

note Loops
repeat 5 times.
  say "Hello!".
end repeat.

for each item in my_list.
  say item.
end for.

note Functions
define greet taking name.
  say "Hello, {name}!".
end define.
greet with "Alice".

note Lists and maps
let fruits be a list of "apple", "banana", "cherry".
let person be a map with "name" as "Alice", "age" as 30.

note Error handling
try.
  raise error "Oops!".
catch err.
  say "Caught: {err}".
end try.

note Classes
define class Dog.
  it has name.
  define create taking name.
    set its name to name.
  end define.
  define speak.
    say "{its name} says Woof!".
  end define.
end class.
let d be a new Dog with "Rex".
call speak on d.
```

---

## Examples

### Hello World
```quill
say "Hello, World!".
```

### Fibonacci
```quill
define fibonacci taking n.
  if n is at most 1.
    return n.
  end if.
  let a be fibonacci with n minus 1.
  let b be fibonacci with n minus 2.
  return a plus b.
end define.

repeat from 0 to 10.
  let result be fibonacci with the current count.
  say "fib({the current count}) = {result}".
end repeat.
```

### GUI Counter App
```quill
use gui.
set theme to "dark".
open a window titled "Counter" with width 320, height 220.

let count be 0.
create a label named countLabel saying "Count: 0".
create a button named addBtn saying "Add 1" that calls addOne.
create a button named resetBtn saying "Reset" that calls resetCount.
place countLabel in window.
place addBtn in window.
place resetBtn in window.

define addOne.
  add 1 to count.
  set the text of countLabel to "Count: {count}".
end define.

define resetCount.
  set count to 0.
  set the text of countLabel to "Count: 0".
end define.

show window.
```

### REST API
```quill
let response be get "https://api.github.com/repos/python/cpython".
let data be parse response as json.
say "Stars: {data at \"stargazers_count\"}".
```

### SQLite Database
```quill
connect to database "todo.db" as db.
execute "CREATE TABLE IF NOT EXISTS tasks (id INTEGER PRIMARY KEY, task TEXT)" on db.
execute "INSERT INTO tasks (task) VALUES (?)" on db with a list of "Buy groceries".
let rows be query db with "SELECT task FROM tasks".
for each row in rows.
  say row at "task".
end for.
```

---

## Project Layout

```
quill-lang/
├── quill/                    ← Interpreter (Python)
│   ├── lexer.py              ← Tokenizer
│   ├── parser.py             ← Recursive-descent parser
│   ├── ast_nodes.py          ← AST node types
│   ├── evaluator.py          ← Tree-walk interpreter
│   ├── gui/                  ← GUI engine (CustomTkinter)
│   └── stdlib/               ← Standard library modules
│       ├── data.py           ← Data science
│       ├── ml.py             ← Machine learning
│       ├── crypto_mod.py     ← Cryptography
│       ├── net.py            ← Networking
│       ├── web_server.py     ← HTTP server
│       └── blockchain.py     ← Blockchain
├── examples/
│   ├── v2/                   ← Quill 2.0 examples
│   ├── fields/               ← Field-specific examples
│   └── games/
│       └── quill_quest/      ← The teaching game
├── docs/
│   └── LANGUAGE_REFERENCE.md ← Full language spec
├── website/                  ← Static website (GitHub Pages)
├── tests/                    ← Test suite
├── install.sh                ← Linux/macOS installer
├── install.ps1               ← Windows installer
├── quill-lang.vsix           ← VS Code extension
├── LICENSE                   ← MIT License (Jero W. Grabo)
└── README.md
```

---

## Credits

**Creator & Lead Developer:** Jero W. Grabo  
**Team:** Quill Language Team  
**License:** MIT — see [LICENSE](LICENSE)  
**Website:** https://quill-lang.org  
**Repository:** https://github.com/quill-lang/quill

---

*"Write code the way you think." — Quill Language Team*
