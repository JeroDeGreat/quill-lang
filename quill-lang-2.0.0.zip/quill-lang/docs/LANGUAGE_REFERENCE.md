# Quill Language Reference
**Version 2.0 — Complete Specification**
*Created by Jero W. Grabo · Quill Language Team*

---

## Core Philosophy

Quill is the world's most readable programming language. Every line is plain
English. The **only** two punctuation characters you will ever use are:

| Symbol | Purpose |
|--------|---------|
| `,` | Separates items (list elements, function arguments) |
| `.` | Ends every statement (like a period ends a sentence) |

No braces. No semicolons. No symbols. If you can speak English, you can write Quill.

---

## Data Types

| Type | Keyword | Example |
|------|---------|---------|
| Whole number | `number` | `42` |
| Decimal number | `decimal` | `3.14` |
| Text | `text` or `word` | `"Hello"` |
| True/false | `truth` | `yes` / `no` |
| Empty | `nothing` | `nothing` |
| Collection | `list` | `a list of 1, 2, 3` |
| Dictionary | `map` | `a map with "key" as "value"` |

---

## Variables

```quill
let age be 25.
let name be "Alice".
let active be yes.
let score be 9.99.
let nothing_yet be nothing.
let colors be a list of "red", "green", "blue".
let profile be a map with "name" as "Alice", "age" as 30.

set age to 26.
set name to "Bob".

let x, y, z be 1, 2, 3.
```

---

## Arithmetic

All operations use English words — no symbols.

```quill
let sum be 5 plus 3.
let diff be 10 minus 4.
let product be 6 times 7.
let quotient be 15 divided by 3.
let remainder be 10 mod 3.
let power be 2 to the power of 8.
let root be square root of 144.
let absolute be absolute value of negative 5.

add 10 to score.
subtract 3 from lives.
multiply price by 1.2.
divide total by count.
```

---

## Comparison & Logic

```quill
if x is 5.             note equals
if x is not 5.         note not equal
if x is greater than 5.
if x is less than 5.
if x is at least 5.    note greater than or equal
if x is at most 5.     note less than or equal
if x is nothing.       note null check

if a and b.
if a or b.
if not a.
```

---

## Conditions

```quill
if age is at least 18.
  say "Adult.".
else if age is 16.
  say "Almost.".
else.
  say "Minor.".
end if.
```

---

## Loops

```quill
repeat 5 times.
  say "Hello!".
end repeat.

repeat from 1 to 10.
  say the current count.
end repeat.

while score is less than 100.
  add 10 to score.
end while.

for each item in items.
  say item.
end for.

stop.    note break out of loop
skip.    note continue to next iteration
```

---

## Functions

```quill
define greet taking name.
  say "Hello, {name}!".
end define.

define add taking a, b.
  return a plus b.
end define.

define greet taking name with default "World".
  say "Hello, {name}!".
end define.

greet with "Alice".
let result be add with 3, 5.
greet.

let double be a function taking x that returns x times 2.
let result be double with 7.
```

---

## Lists

```quill
let fruits be a list of "apple", "banana", "cherry".
let empty be an empty list.

add "mango" to fruits.
remove "banana" from fruits.
let count be the size of fruits.
let first be the first item in fruits.
let last be the last item in fruits.
let third be the item 3 of fruits.

let biggest be the maximum of fruits.
let smallest be the minimum of fruits.
let total be the sum of fruits.
let sorted be fruits sorted descending.
let joined be fruits joined by ", ".

for each fruit in fruits.
  say fruit.
end for.
```

---

## Maps (Dictionaries)

```quill
let person be a map with "name" as "Alice", "age" as 30.
let name be person at "name".
set person at "email" to "alice@example.com".
remove "age" from person.
```

---

## Strings

```quill
let upper be name in uppercase.
let lower be name in lowercase.
let trimmed be name trimmed.
let parts be sentence split by " ".
let joined be "Hello" joined with " World".
let replaced be text with "old" replaced by "new".
let length be the length of name.

if name starts with "A".
if name ends with "z".
if name contains "li".
```

---

## Classes & Objects

```quill
define class Animal.
  it has name, sound.

  define create taking name, sound.
    set its name to name.
    set its sound to sound.
  end define.

  define speak.
    say "{its name} says {its sound}!".
  end define.
end class.

define class Dog extending Animal.
  define fetch.
    say "{its name} fetches the ball!".
  end define.
end class.

let cat be a new Animal with "Whiskers", "Meow".
call speak on cat.
```

---

## Error Handling

```quill
try.
  let result be divide 10 by 0.
catch error.
  say "Caught: {error}".
end try.

raise error "Something went wrong.".
```

---

## File I/O

```quill
use files.

write "Hello!" to file "output.txt".
append "More text." to file "output.txt".
let content be the content of file "output.txt".
delete file "output.txt".

if file "data.txt" exists.
  say "Found it!".
end if.
```

---

## HTTP Requests

```quill
let response be get "https://api.example.com/data".
let data be parse response as json.
say data at "field".

let result be post to "https://api.example.com" with my_map.
```

---

## Database (SQLite)

```quill
connect to database "myapp.db" as db.

execute "CREATE TABLE IF NOT EXISTS users (id INTEGER PRIMARY KEY, name TEXT)" on db.
execute "INSERT INTO users (name) VALUES (?)" on db with a list of "Alice".

let users be query db with "SELECT id, name FROM users".
for each user in users.
  say "{user at \"id\"}: {user at \"name\"}".
end for.
```

---

## Standard Library Modules

Load modules with `use MODULE_NAME.`

### use math
```quill
use math.
say pi.
say e.
let root be square root of 16.
```

### use files
File reading, writing, appending, deleting.

### use random
```quill
use random.
let n be random number between 1 and 100.
```

### use time
```quill
use time.
say current time.
say current date.
wait 2 seconds.
```

### use os
```quill
use os.
run command "ls -la" into output.
say output.
```

### use json
```quill
use json.
let text be "{\"key\": \"value\"}".
let parsed be parse text as json.
```

### use web
```quill
let html be get "https://example.com".
```

### use gui
See GUI Reference below.

### use data
```quill
use data.
let rows be read csv "file.csv".
let avg be average of my_numbers.
let sorted be sort rows by "name".
let filtered be filter rows by "age", "30".
```

### use ml
```quill
use ml.
let model be linear regression x_values, y_values.
let prediction be predict linear model, 5.
let classifier be train naive bayes texts, labels.
let result be predict naive bayes classifier, "new text".
```

### use crypto
```quill
use crypto.
let hashed be hash text "mypassword".
let token be generate token.
let strong_pwd be generate password.
let strength be check password strength "my_password123".
```

### use net
```quill
use net.
let ip be dns lookup "google.com".
let open be is port open "example.com", 80.
```

### use server
```quill
use server.
add route "/", "handleHome".
start server 8080.
```

### use blockchain
```quill
use blockchain.
let result be create blockchain "mychain".
let hash be add to blockchain "mychain", "transaction data".
let valid be validate blockchain "mychain".
```

---

## GUI Reference

```quill
use gui.
set theme to "dark".
open a window titled "My App" with width 800, height 600.

create a label named myLabel saying "Hello!".
create a button named myBtn saying "Click Me" that calls onBtnClick.
create a text input named myInput with placeholder "Type here".
create a checkbox named myCheck saying "Enable feature".
create a toggle named myToggle saying "Dark Mode".
create a dropdown named myDrop with choices "Option A", "Option B".
create a slider named mySlider from 0 to 100.
create a progress bar named myProgress.
create a table named myTable with columns "Name", "Value".
create a bar chart named myChart titled "My Chart".
create a row layout named myRow.
create a card layout named myCard titled "Card Title".

add myLabel, myBtn to myRow.
place myRow in window.
show window.

set the text of myLabel to "Updated!".
set progress of myProgress to 75.
set data of myChart to my_labels, my_values.
add row "Alice", 92 to myTable.
show a toast saying "Hello!".
```

---

## String Interpolation

Use `{variableName}` inside any string to embed values:

```quill
let name be "Alice".
let age be 30.
say "Hello, {name}! You are {age} years old.".
say "Current level: {the current count}".
say "Inside a class: {its name}".
say "List size: {the size of my_list}".
```

---

## Comments

```quill
note This is a single-line comment.

begin note.
  This is a multi-line comment.
  It can span as many lines as needed.
end note.
```

---

## Including Other Files

```quill
include "helpers.ql".
include "config.ql".
```

---

## Timers (in GUI apps)

```quill
every 5 seconds call refreshData.
wait 2 seconds.
```

---

*Full documentation at https://quill-lang.org/docs*
*Created by Jero W. Grabo · MIT License*
