# Quill Language 2.0 Installer for Windows
# Run with: powershell -ExecutionPolicy Bypass -File ".\install.ps1"

$QuillVersion = "2.0.0"
$InstallDir   = Join-Path $env:APPDATA "Quill"
$BinDir       = Join-Path $InstallDir "bin"
$ScriptDir    = Split-Path -Parent $MyInvocation.MyCommand.Path

Write-Host ""
Write-Host "==========================================" -ForegroundColor Cyan
Write-Host "  Quill $QuillVersion  - Write code the way you think." -ForegroundColor Cyan
Write-Host "==========================================" -ForegroundColor Cyan
Write-Host ""

Write-Host "  -> Checking for Python 3.10 or newer..." -ForegroundColor Blue
$Python = $null
foreach ($cmd in @("python3", "python")) {
    try {
        $verOutput = & $cmd -c "import sys; v=sys.version_info; print(v[0],v[1])" 2>$null
        if ($verOutput) {
            $parts = $verOutput.Trim() -split ' '
            $major = [int]$parts[0]; $minor = [int]$parts[1]
            if ($major -ge 3 -and $minor -ge 10) {
                $Python = $cmd
                Write-Host "  OK Found Python $major.$minor" -ForegroundColor Green
                break
            }
        }
    } catch {}
}
if (-not $Python) {
    Write-Host "  ERROR: Python 3.10+ required. Get it from https://python.org" -ForegroundColor Red
    exit 1
}

Write-Host "  -> Creating install directory..." -ForegroundColor Blue
New-Item -ItemType Directory -Force -Path $BinDir | Out-Null
New-Item -ItemType Directory -Force -Path (Join-Path $InstallDir "lib") | Out-Null
Write-Host "  OK Directory ready" -ForegroundColor Green

Write-Host "  -> Copying Quill interpreter..." -ForegroundColor Blue
$QuillSrc = Join-Path $ScriptDir "quill"
$QuillDst = Join-Path $InstallDir "lib\quill"
if (Test-Path $QuillSrc) {
    if (Test-Path $QuillDst) { Remove-Item -Recurse -Force $QuillDst }
    Copy-Item -Recurse $QuillSrc $QuillDst
    Write-Host "  OK Interpreter installed" -ForegroundColor Green
} else {
    Write-Host "  ERROR: Cannot find quill source at $QuillSrc" -ForegroundColor Red
    exit 1
}

Write-Host "  -> Installing CustomTkinter (modern UI)..." -ForegroundColor Blue
try {
    & $Python -m pip install --quiet customtkinter 2>$null
    Write-Host "  OK CustomTkinter installed (beautiful modern UI)" -ForegroundColor Green
} catch {
    Write-Host "  WARN CustomTkinter not installed - GUI will use standard tkinter" -ForegroundColor Yellow
}

Write-Host "  -> Creating quill.bat launcher..." -ForegroundColor Blue
$LibDir = Join-Path $InstallDir "lib"
$BatchLines = "@echo off", "set PYTHONPATH=$LibDir;%PYTHONPATH%", "$Python -m quill %*"
$BatchPath = Join-Path $BinDir "quill.bat"
$BatchLines | Set-Content -Path $BatchPath -Encoding ASCII
Write-Host "  OK Launcher created" -ForegroundColor Green

if (Test-Path (Join-Path $ScriptDir "quill-lang.vsix")) {
    Copy-Item (Join-Path $ScriptDir "quill-lang.vsix") (Join-Path $InstallDir "quill-lang.vsix")
}

Write-Host "  -> Registering .ql file type..." -ForegroundColor Blue
try {
    New-Item -Path "HKCU:\Software\Classes\.ql" -Force | Out-Null
    Set-ItemProperty -Path "HKCU:\Software\Classes\.ql" -Name "(Default)" -Value "QuillSourceFile"
    Set-ItemProperty -Path "HKCU:\Software\Classes\.ql" -Name "Content Type" -Value "text/x-quill"
    New-Item -Path "HKCU:\Software\Classes\QuillSourceFile" -Force | Out-Null
    Set-ItemProperty -Path "HKCU:\Software\Classes\QuillSourceFile" -Name "(Default)" -Value "Quill Source File"
    New-Item -Path "HKCU:\Software\Classes\QuillSourceFile\shell\open\command" -Force | Out-Null
    Set-ItemProperty -Path "HKCU:\Software\Classes\QuillSourceFile\shell\open\command" -Name "(Default)" -Value "`"$BinDir\quill.bat`" run `"%1`""
    New-Item -Path "HKCU:\Software\Classes\QuillSourceFile\DefaultIcon" -Force | Out-Null
    Set-ItemProperty -Path "HKCU:\Software\Classes\QuillSourceFile\DefaultIcon" -Name "(Default)" -Value "$InstallDir\quill-icon.ico,0"
    Write-Host "  OK .ql file type registered" -ForegroundColor Green
} catch {
    Write-Host "  WARN File type registration skipped" -ForegroundColor Yellow
}

Write-Host "  -> Adding Quill to your PATH..." -ForegroundColor Blue
$CurrentPath = [Environment]::GetEnvironmentVariable("Path", "User")
if ($CurrentPath -notlike "*$BinDir*") {
    [Environment]::SetEnvironmentVariable("Path", "$BinDir;$CurrentPath", "User")
    $env:Path = "$BinDir;$env:Path"
    Write-Host "  OK Added to PATH" -ForegroundColor Green
} else {
    Write-Host "  OK Already in PATH" -ForegroundColor Green
}

if (Get-Command code -ErrorAction SilentlyContinue) {
    $VsixInst = Join-Path $InstallDir "quill-lang.vsix"
    if (Test-Path $VsixInst) {
        try {
            & code --install-extension $VsixInst --force 2>$null
            Write-Host "  OK VS Code extension installed" -ForegroundColor Green
        } catch {}
    }
}

Write-Host "  -> Verifying..." -ForegroundColor Blue
try {
    $env:PYTHONPATH = "$LibDir;$env:PYTHONPATH"
    $ver = & "$BinDir\quill.bat" version 2>$null
    Write-Host "  OK $ver" -ForegroundColor Green
} catch {
    Write-Host "  WARN Open a new terminal before using quill" -ForegroundColor Yellow
}

Write-Host ""
Write-Host "  Quill 2.0 is ready!" -ForegroundColor Green
Write-Host ""
Write-Host "  Open a NEW PowerShell window, then try:" -ForegroundColor White
Write-Host "    quill version" -ForegroundColor Cyan
Write-Host "    quill run examples\v2\sentiment_analyzer.ql" -ForegroundColor Cyan
Write-Host "    quill run examples\v2\dashboard.ql" -ForegroundColor Cyan
Write-Host "    quill run examples\v2\todo_database.ql" -ForegroundColor Cyan
Write-Host ""
