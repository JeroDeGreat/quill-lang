note Fibonacci sequence using recursion.

define fibonacci taking n.
  if n is at most 1.
    return n.
  end if.
  let a be fibonacci with n minus 1.
  let b be fibonacci with n minus 2.
  return a plus b.
end define.

say "Fibonacci sequence:".
repeat from 0 to 12.
  let result be fibonacci with the current count.
  say "  fib({the current count}) = {result}".
end repeat.
