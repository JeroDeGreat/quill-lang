note Number guessing game.
note Uses "random number between X and Y" syntax.

use random.

let secret be random number between 1 and 100.
let tries be 0.
let guessed be no.

say "I am thinking of a number between 1 and 100.".
say "Can you guess it?".
say "".

while guessed is no.
  ask "Your guess:" into guess as number.
  add 1 to tries.

  if guess is less than secret.
    say "Too low! Try higher.".
  else if guess is greater than secret.
    say "Too high! Try lower.".
  else.
    set guessed to yes.
    say "".
    say "Correct! You got it in {tries} tries!".
  end if.
end while.
