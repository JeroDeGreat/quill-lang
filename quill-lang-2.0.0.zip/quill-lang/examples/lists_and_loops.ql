note Demonstrates lists, loops, and string operations.

let fruits be a list of "apple", "banana", "cherry", "date", "elderberry".

say "All fruits:".
for each fruit in fruits.
  say "  {fruit}".
end for.

say "".
say "Uppercase:".
for each fruit in fruits.
  let up be fruit in uppercase.
  say "  {up}".
end for.

say "".
let count be the size of fruits.
say "I have {count} fruits total.".

say "".
say "Fruits containing the letter e:".
for each fruit in fruits.
  if fruit contains "e".
    say "  {fruit}".
  end if.
end for.

add "fig" to fruits.
say "".
say "After adding fig, I have {the size of fruits} fruits.".
