note A simple to-do list saved to a file.

use files.

let filename be "todo.txt".
let running be yes.

say "To-Do List  (saved to {filename})".
say "Commands: add, list, done".
say "".

while running is yes.
  ask "Command:" into cmd.

  if cmd is "add".
    ask "New task:" into task.
    append "{task}" to file filename.
    append " | " to file filename.
    say "Task added.".

  else if cmd is "list".
    if file filename exists.
      let content be the content of file filename.
      let tasks be content split by " | ".
      let count be the size of tasks.
      say "Your {count} tasks:".
      repeat from 1 to count.
        let task be the item the current count of tasks.
        say "  {the current count}. {task}".
      end repeat.
    else.
      say "No tasks yet.".
    end if.

  else if cmd is "done".
    set running to no.
    say "See you next time!".

  else.
    say "Unknown command. Try: add, list, done.".
  end if.
end while.
