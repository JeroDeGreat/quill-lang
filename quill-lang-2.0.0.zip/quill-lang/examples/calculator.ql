note A simple interactive calculator.

say "Welcome to the Quill Calculator!".
say "".

ask "Enter a number:" into a as number.
ask "Enter another number:" into b as number.

let sum be a plus b.
let difference be a minus b.
let product be a times b.

say "{a} plus {b} is {sum}.".
say "{a} minus {b} is {difference}.".
say "{a} times {b} is {product}.".

if b is not 0.
  let quotient be a divided by b.
  say "{a} divided by {b} is {quotient}.".
else.
  say "I cannot divide by zero.".
end if.
