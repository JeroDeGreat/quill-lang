note Demonstrate math operations and number facts.

use math.

ask "Enter a number:" into n as number.

say "".
say "Facts about {n}:".

let squared be n times n.
say "  Squared:      {squared}".

let cubed be n times n times n.
say "  Cubed:        {cubed}".

let root be square root of n.
say "  Square root:  {root}".

let r2 be n mod 2.
if r2 is 0.
  say "  Even or odd:  Even".
else.
  say "  Even or odd:  Odd".
end if.

if n is greater than 0.
  say "  Sign:         Positive".
else if n is less than 0.
  say "  Sign:         Negative".
else.
  say "  Sign:         Zero".
end if.
