note Count words in a text file.
note Usage: type a filename when asked.

use files.

ask "Enter a filename:" into filename.

if file filename exists.
  let content be the content of file filename.
  let words be content split by " ".
  let wordcount be the size of words.
  say "File: {filename}".
  say "Words: {wordcount}".
else.
  say "File not found: {filename}".
end if.
