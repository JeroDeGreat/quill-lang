note File reading and writing example.

use files.

note Write a sample file with three lines.
write "Line one: Hello from Quill." to file "sample.txt".
append " | Line two: This is a test." to file "sample.txt".
append " | Line three: File I/O works!" to file "sample.txt".

note Read it back.
let content be the content of file "sample.txt".
say "File contents:".
say content.
say "".

note Split on the separator we used.
let parts be content split by " | ".
let count be the size of parts.
say "The file has {count} sections.".

for each part in parts.
  say "  {part}".
end for.

note Clean up.
delete file "sample.txt".
say "Done.".
