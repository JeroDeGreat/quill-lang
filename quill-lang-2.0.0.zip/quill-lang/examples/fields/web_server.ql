note Simple HTTP Web Server in Quill.
note Visit http://localhost:8080 after running.

use server.

say "Starting Quill Web Server...".
say "".

define handle_home.
  return "Hello from Quill Web Server 2.0!".
end define.

define handle_about.
  return "Quill - Write code the way you think.".
end define.

define handle_api.
  return "status ok language Quill version 2.0".
end define.

addroute with "/", "handle_home".
addroute with "/about", "handle_about".
addroute with "/api", "handle_api".

say "Routes registered:".
say "  http://localhost:8080/".
say "  http://localhost:8080/about".
say "  http://localhost:8080/api".
say "".
say "Press Ctrl+C to stop.".

start server 8080.
