note Blockchain Demo — mine blocks, validate chain.

use blockchain.

say "Quill Blockchain Demo".
say "".

let setup be newblockchain with "quillchain".
say setup.
say "".

say "Mining transactions...".
let h1 be addblock with "quillchain", "Alice sends 50 QLC to Bob".
say "Block 1: {h1}".

let h2 be addblock with "quillchain", "Bob sends 20 QLC to Carol".
say "Block 2: {h2}".

let h3 be addblock with "quillchain", "Carol sends 10 QLC to Dave".
say "Block 3: {h3}".
say "".

let length be blocklength with "quillchain".
say "Chain length: {length} blocks".

let valid be validateblockchain with "quillchain".
say "Chain valid: {valid}".
say "".

let chain be getblockchain with "quillchain".
say "Full Blockchain:".
for each block in chain.
  let block_index be block at "index".
  let block_data be block at "data".
  let block_hash be block at "hash".
  say "  Block {block_index}: {block_data}".
  say "    Hash: {block_hash}".
end for.
