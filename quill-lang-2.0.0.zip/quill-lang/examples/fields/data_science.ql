note Data Science Pipeline — CSV loading, stats, analysis.

use data.
use files.

say "Quill Data Science Pipeline".
say "".

write "name,age,salary,department" to file "_staff.csv".
append "Alice,28,75000,Engineering" to file "_staff.csv".
append "Bob,35,92000,Engineering" to file "_staff.csv".
append "Carol,31,68000,Marketing" to file "_staff.csv".
append "David,42,115000,Engineering" to file "_staff.csv".
append "Eve,29,71000,Marketing" to file "_staff.csv".
append "Frank,38,88000,HR" to file "_staff.csv".
append "Grace,26,65000,Marketing" to file "_staff.csv".
append "Henry,45,125000,Engineering" to file "_staff.csv".

let staff be readcsv with "_staff.csv".
let count be the size of staff.
say "Loaded {count} records.".
say "".

let salary_strings be columnvals with staff, "salary".
let salaries be an empty list.
for each s in salary_strings.
  let n be 0.
  try.
    set n to s.
  catch e.
    set n to 0.
  end try.
  add n to salaries.
end for.

let avg_sal be average with salaries.
let med_sal be median with salaries.
let max_sal be the maximum of salaries.
let min_sal be the minimum of salaries.

say "Salary Statistics:".
say "  Average : {avg_sal}".
say "  Median  : {med_sal}".
say "  Highest : {max_sal}".
say "  Lowest  : {min_sal}".
say "".

let dept_counts be countby with staff, "department".
say "Headcount by Department:".
for each dept in dept_counts.
  let dept_count be dept_counts at dept.
  say "  {dept}: {dept_count}".
end for.
say "".

say "Top Earners (90k+):".
for each person in staff.
  let sal be 0.
  try.
    set sal to person at "salary".
  catch e.
    set sal to 0.
  end try.
  if sal is at least 90000.
    let person_name be person at "name".
    let person_salary be person at "salary".
    let person_dept be person at "department".
    say "  {person_name}: {person_salary} in {person_dept}".
  end if.
end for.

delete file "_staff.csv".
say "".
say "Done!".
