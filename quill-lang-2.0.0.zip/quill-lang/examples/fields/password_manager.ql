note Password Manager using Quill crypto module.

use crypto.
use files.

say "Quill Password Manager".
say "".

define store_password taking service, pwd.
  let hashed be hash with pwd.
  let entry be service joined with ":" joined with hashed.
  append entry to file "vault.txt".
  append "~" to file "vault.txt".
  say "Stored password for: {service}".
end define.

define check_password taking service, pwd.
  if file "vault.txt" exists.
    let contents be the content of file "vault.txt".
    let hashed be hash with pwd.
    let target be service joined with ":" joined with hashed.
    if contents contains target.
      say "Password for {service} is CORRECT.".
      return yes.
    else.
      say "Password for {service} is WRONG.".
      return no.
    end if.
  else.
    say "No vault found. Store a password first.".
    return no.
  end if.
end define.

define show_strength taking pwd.
  let result be passwordstrength with pwd.
  let rating be result at "rating".
  let score be result at "score".
  say "Strength: {rating} — Score: {score}/100".
  let tips be result at "feedback".
  for each tip in tips.
    say "  Tip: {tip}".
  end for.
end define.

say "Commands: store, check, generate, strength, quit".
say "".

let running be yes.
while running is yes.
  ask "Command:" into cmd.

  if cmd is "store".
    ask "Service:" into svc.
    ask "Password:" into pwd.
    store_password with svc, pwd.

  else if cmd is "check".
    ask "Service:" into svc.
    ask "Password:" into pwd.
    check_password with svc, pwd.

  else if cmd is "generate".
    let newpwd be password.
    say "Generated: {newpwd}".
    show_strength with newpwd.

  else if cmd is "strength".
    ask "Password to check:" into pwd.
    show_strength with pwd.

  else if cmd is "quit".
    set running to no.
    say "Goodbye!".
  end if.
end while.
