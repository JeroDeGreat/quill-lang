note Network Scanner — DNS, ports, IP tools.

use net.

say "Quill Network Scanner".
say "".

say "Your local IP: {my ip}".
say "".

say "DNS Lookups:".
let ip1 be dnslookup with "google.com".
let ip2 be dnslookup with "github.com".
let ip3 be dnslookup with "cloudflare.com".
say "  google.com     -> {ip1}".
say "  github.com     -> {ip2}".
say "  cloudflare.com -> {ip3}".
say "".

say "Port Check on google.com:".
let http_open be isportopen with "google.com", 80.
let https_open be isportopen with "google.com", 443.
let ftp_open be isportopen with "google.com", 21.
say "  Port 80  HTTP  : {http_open}".
say "  Port 443 HTTPS : {https_open}".
say "  Port 21  FTP   : {ftp_open}".
say "".

say "URL Parser:".
let parsed be urlparse with "https://github.com/quill-lang/quill?ref=main".
let url_scheme be parsed at "scheme".
let url_host be parsed at "host".
let url_path be parsed at "path".
let url_query be parsed at "query".
say "  Scheme: {url_scheme}".
say "  Host:   {url_host}".
say "  Path:   {url_path}".
say "  Query:  {url_query}".
say "".

ask "Enter a hostname to look up:" into host.
let ip be dnslookup with host.
say "IP: {ip}".

ask "Check a port? Enter number (or skip):" into port_input.
if port_input is not "skip".
  let open_result be isportopen with host, port_input.
  say "Port {port_input} on {host}: {open_result}".
end if.
