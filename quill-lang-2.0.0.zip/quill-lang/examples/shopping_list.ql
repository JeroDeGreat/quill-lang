note An interactive shopping list manager.

let items be an empty list.
let running be yes.

say "Shopping List Manager".
say "Commands: add, remove, list, done".
say "".

while running is yes.
  ask "What would you like to do?" into command.

  if command is "add".
    ask "What item?" into item.
    add item to items.
    say "Added: {item}".

  else if command is "remove".
    ask "Which item to remove?" into item.
    remove item from items.
    say "Removed: {item}".

  else if command is "list".
    let count be the size of items.
    if count is 0.
      say "Your list is empty.".
    else.
      say "Your {count} items:".
      for each item in items.
        say "  - {item}".
      end for.
    end if.

  else if command is "done".
    set running to no.
    say "Goodbye!".

  else.
    say "I do not understand that command.".
  end if.
end while.
