note FizzBuzz — a classic programming challenge.
note Multiples of 3 say Fizz, multiples of 5 say Buzz, both say FizzBuzz.

repeat from 1 to 30.
  let n be the current count.
  let by3 be n mod 3.
  let by5 be n mod 5.

  if by3 is 0 and by5 is 0.
    say "FizzBuzz".
  else if by3 is 0.
    say "Fizz".
  else if by5 is 0.
    say "Buzz".
  else.
    say n.
  end if.
end repeat.
