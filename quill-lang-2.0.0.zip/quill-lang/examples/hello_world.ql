note The simplest Quill program.

say "Hello, World!".
