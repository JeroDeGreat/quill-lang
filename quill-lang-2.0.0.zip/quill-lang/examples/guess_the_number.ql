note Guess the number game.

use random.

let secret be random number between 1 and 100.
let guesses be 0.
let won be no.

say "I am thinking of a number between 1 and 100.".

while won is no.
  ask "Your guess:" into guess as number.
  add 1 to guesses.

  if guess is less than secret.
    say "Too low! Try higher.".
  else if guess is greater than secret.
    say "Too high! Try lower.".
  else.
    set won to yes.
    say "Correct! You got it in {guesses} guesses!".
  end if.
end while.
