note QUILL QUEST — Learn to code in Quill through 15 challenges.
note Created by Jero W. Grabo — Quill Language Team.

use gui.

set theme to "dark".
open a window titled "Quill Quest — Learn to Code" with width 1000, height 700.

note Game state variables
let current_level be 1.
let total_score be 0.
let lives be 3.
let attempts be 0.
let game_started be no.
let total_levels be 15.
let badges_earned be "".

note Header row
create a label named gameTitleLabel saying "Quill Quest".
create a label named scoreLabel saying "Score: 0".
create a label named livesLabel saying "Lives: 3".
create a label named levelLabel saying "Level 1 of 15".
add gameTitleLabel, scoreLabel, livesLabel, levelLabel to headerRow.

note Progress
create a label named progressLabel saying "Progress: 0%".
create a progress bar named questProgress.

note Story and challenge
create a label named storyLabel saying "Welcome to Quill Quest! Press Start to begin.".
create a label named challengeLabel saying "Your challenge will appear here.".

note Hint area
create a label named hintLabel saying "Press Get Hint for help.".
create a label named exampleLabel saying "".

note Code input
create a label named editorPrompt saying "Type your Quill code answer below:".
create a text input named codeInput with placeholder "Type your answer here...".

note Buttons
create a button named startBtn saying "Start Quest" that calls startGame.
create a button named submitBtn saying "Submit Answer" that calls submitAnswer.
create a button named hintBtn saying "Get Hint" that calls showHint.
create a button named exampleBtn saying "Show Example (costs a life)" that calls showExample.
create a button named nextBtn saying "Next Level" that calls nextLevel.
add startBtn, submitBtn to buttonRowA.
add hintBtn, exampleBtn, nextBtn to buttonRowB.

note Result display
create a label named resultLabel saying "".
create a label named feedbackLabel saying "".

note Badge display
create a label named badgeLabel saying "Complete levels to earn badges!".

note Settings
create a dropdown named difficultyDropdown with choices "Beginner", "Normal", "Hard".
create a label named settingsLabel saying "Difficulty:".
add settingsLabel, difficultyDropdown to settingsRow.

note Place everything in window
place headerRow in window.
place progressLabel in window.
place questProgress in window.
place storyLabel in window.
place challengeLabel in window.
place hintLabel in window.
place exampleLabel in window.
place editorPrompt in window.
place codeInput in window.
place buttonRowA in window.
place buttonRowB in window.
place resultLabel in window.
place feedbackLabel in window.
place badgeLabel in window.
place settingsRow in window.

note Level data functions

define get_story taking level.
  if level is 1. return "The ancient Quill Oracle must be awakened with a greeting.". end if.
  if level is 2. return "The Oracle needs to remember your name.". end if.
  if level is 3. return "A magic gate requires the product of 7 and 8.". end if.
  if level is 4. return "A gatekeeper only allows adults to pass through.". end if.
  if level is 5. return "The Echo Chamber must repeat a sound exactly 5 times.". end if.
  if level is 6. return "Mages store reusable spells as named functions.". end if.
  if level is 7. return "A treasure chest holds a collection of 3 colors.". end if.
  if level is 8. return "The Codex stores knowledge as key-value pairs.". end if.
  if level is 9. return "Even brave heroes need safety nets for errors.". end if.
  if level is 10. return "Great mages create objects with data and behavior.". end if.
  if level is 11. return "The Royal Scribe records everything to parchment files.". end if.
  if level is 12. return "Messenger hawks carry data across the internet.". end if.
  if level is 13. return "The Vault Keeper stores data forever in a database.". end if.
  if level is 14. return "Master window makers craft beautiful interfaces.". end if.
  if level is 15. return "The Grand Finale — combine everything you have learned!". end if.
  return "Continue your quest...".
end define.

define get_challenge taking level.
  if level is 1. return "Print: Hello, Quill!". end if.
  if level is 2. return "Store your name in a variable and print a greeting.". end if.
  if level is 3. return "Create a variable result equal to 7 times 8 and print it.". end if.
  if level is 4. return "Check if age is at least 18 and print the right message.". end if.
  if level is 5. return "Use repeat to print Echo! exactly 5 times.". end if.
  if level is 6. return "Define a function greet that takes a name and prints a greeting.". end if.
  if level is 7. return "Create a list of 3 colors and print each one.". end if.
  if level is 8. return "Create a map with name and age keys then print both values.". end if.
  if level is 9. return "Write a try and catch block that catches any error.". end if.
  if level is 10. return "Create an Animal class with name, sound, and a speak method.". end if.
  if level is 11. return "Write to a file, read it back, and print the content.". end if.
  if level is 12. return "Fetch your IP from https://api.ipify.org and print it.". end if.
  if level is 13. return "Connect to SQLite, create a table, insert and query a row.". end if.
  if level is 14. return "Build a GUI window with a label and show it.". end if.
  if level is 15. return "Combine: a function, a list, a loop, and a condition.". end if.
  return "Complete the challenge.".
end define.

define get_hint taking level.
  if level is 1. return "Use: say followed by your text in quotes, then a period.". end if.
  if level is 2. return "Use: let name be then your name. Then say with name in curly braces.". end if.
  if level is 3. return "Use the word times for multiplication. No star symbol needed.". end if.
  if level is 4. return "Use: if age is at least 18. then else. then end if.". end if.
  if level is 5. return "Use: repeat 5 times. then your code. then end repeat.". end if.
  if level is 6. return "Use: define greet taking name. then end define. Call with greet with.". end if.
  if level is 7. return "Use: let x be a list of then values. Loop with for each.". end if.
  if level is 8. return "Use: a map with key as value. Access with map at key.". end if.
  if level is 9. return "Use: try. then code. then catch error. then end try.". end if.
  if level is 10. return "Use: define class X. then it has fields. then methods. then end class.". end if.
  if level is 11. return "Use: write text to file name. Then the content of file name.". end if.
  if level is 12. return "Use: let response be get followed by the URL in quotes.". end if.
  if level is 13. return "Use: connect to database name as db. Then execute SQL on db.". end if.
  if level is 14. return "Use: use gui. open a window. create a label. show window.". end if.
  if level is 15. return "Combine define, a list of, for each, and if together.". end if.
  return "Think carefully and try your best!".
end define.

define get_example taking level.
  if level is 1. return "say Hello, Quill!.". end if.
  if level is 2. return "let name be Alice. say Hello, name.". end if.
  if level is 3. return "let result be 7 times 8. say result.". end if.
  if level is 4. return "let age be 20. if age is at least 18. say Welcome!. else. say Sorry.. end if.". end if.
  if level is 5. return "repeat 5 times. say Echo!. end repeat.". end if.
  if level is 6. return "define greet taking name. say Hello name. end define. greet with World.". end if.
  if level is 7. return "let colors be a list of red, green, blue. for each c in colors. say c. end for.". end if.
  if level is 8. return "let p be a map with name as Alice, age as 30. say p at name. say p at age.". end if.
  if level is 9. return "try. raise error test.. catch err. say Caught: err.. end try.". end if.
  if level is 10. return "define class Dog. it has name. define create taking name. set its name to name. end define. end class.". end if.
  return "See the language reference at docs/LANGUAGE_REFERENCE.md".
end define.

define get_badge taking level.
  if level is 1. return "First Words". end if.
  if level is 2. return "Memory Keeper". end if.
  if level is 3. return "Number Cruncher". end if.
  if level is 4. return "Logic Master". end if.
  if level is 5. return "Loop Rider". end if.
  if level is 6. return "Spell Weaver". end if.
  if level is 7. return "List Keeper". end if.
  if level is 8. return "Codex Reader". end if.
  if level is 9. return "Error Handler". end if.
  if level is 10. return "Golem Maker". end if.
  if level is 11. return "Scribe". end if.
  if level is 12. return "Net Hawk". end if.
  if level is 13. return "Vault Keeper". end if.
  if level is 14. return "Window Maker". end if.
  if level is 15. return "Quill Master". end if.
  return "Adventurer".
end define.

define get_points taking level.
  if level is at most 5. return 10. end if.
  if level is at most 10. return 25. end if.
  if level is 15. return 100. end if.
  return 40.
end define.

note Game logic functions

define update_display.
  let story be get_story with current_level.
  let challenge be get_challenge with current_level.
  let pct be current_level minus 1 times 100 divided by total_levels.
  set the text of storyLabel to story.
  set the text of challengeLabel to "Challenge: {challenge}".
  set the text of scoreLabel to "Score: {total_score}".
  set the text of levelLabel to "Level {current_level} of {total_levels}".
  set the text of progressLabel to "Progress: {pct}%".
  set progress of questProgress to pct.
  set the text of resultLabel to "".
  set the text of feedbackLabel to "".
  set the text of hintLabel to "Press Get Hint for help.".
  set the text of exampleLabel to "".
  set attempts to 0.
  let lives_text be "Lives: {lives}".
  set the text of livesLabel to lives_text.
end define.

define startGame.
  set game_started to yes.
  set current_level to 1.
  set total_score to 0.
  set lives to 3.
  set badges_earned to "".
  update_display.
  set the text of resultLabel to "Good luck! Type your answer in the code box below.".
  show a toast saying "Quest started! Level 1 awaits.".
end define.

define showHint.
  if game_started is no.
    show a toast saying "Press Start Quest first!".
    return.
  end if.
  let hint be get_hint with current_level.
  set the text of hintLabel to "Hint: {hint}".
  show a toast saying "Hint revealed!".
end define.

define showExample.
  if game_started is no.
    show a toast saying "Press Start Quest first!".
    return.
  end if.
  if lives is 0.
    show a toast saying "No lives remaining!".
    return.
  end if.
  subtract 1 from lives.
  let lives_text be "Lives: {lives}".
  set the text of livesLabel to lives_text.
  let example be get_example with current_level.
  set the text of exampleLabel to "Example: {example}".
  show a toast saying "Example shown. One life deducted.".
end define.

define check_answer taking code_lower.
  if current_level is 1.
    if code_lower contains "say" and code_lower contains "hello, quill".
      return yes.
    end if.
    return no.
  end if.
  if current_level is 2.
    if code_lower contains "let" and code_lower contains "be" and code_lower contains "say".
      return yes.
    end if.
    return no.
  end if.
  if current_level is 3.
    if code_lower contains "times" and code_lower contains "say".
      return yes.
    end if.
    return no.
  end if.
  if current_level is 4.
    if code_lower contains "if" and code_lower contains "at least" and code_lower contains "else".
      return yes.
    end if.
    return no.
  end if.
  if current_level is 5.
    if code_lower contains "repeat" and code_lower contains "times" and code_lower contains "end repeat".
      return yes.
    end if.
    return no.
  end if.
  if current_level is 6.
    if code_lower contains "define" and code_lower contains "taking" and code_lower contains "end define".
      return yes.
    end if.
    return no.
  end if.
  if current_level is 7.
    if code_lower contains "a list of" and code_lower contains "for each" and code_lower contains "end for".
      return yes.
    end if.
    return no.
  end if.
  if current_level is 8.
    if code_lower contains "a map with" and code_lower contains "as" and code_lower contains "at".
      return yes.
    end if.
    return no.
  end if.
  if current_level is 9.
    if code_lower contains "try" and code_lower contains "catch" and code_lower contains "end try".
      return yes.
    end if.
    return no.
  end if.
  if current_level is 10.
    if code_lower contains "define class" and code_lower contains "it has" and code_lower contains "end class".
      return yes.
    end if.
    return no.
  end if.
  if current_level is 11.
    if code_lower contains "write" and code_lower contains "to file" and code_lower contains "content of file".
      return yes.
    end if.
    return no.
  end if.
  if current_level is 12.
    if code_lower contains "get" and code_lower contains "say".
      return yes.
    end if.
    return no.
  end if.
  if current_level is 13.
    if code_lower contains "connect to database" and code_lower contains "execute" and code_lower contains "query".
      return yes.
    end if.
    return no.
  end if.
  if current_level is 14.
    if code_lower contains "use gui" and code_lower contains "open a window" and code_lower contains "show window".
      return yes.
    end if.
    return no.
  end if.
  if current_level is 15.
    if code_lower contains "define" and code_lower contains "a list of" and code_lower contains "for each" and code_lower contains "if".
      return yes.
    end if.
    return no.
  end if.
  return no.
end define.

define submitAnswer.
  if game_started is no.
    show a toast saying "Press Start Quest first!".
    return.
  end if.
  let code be the value of codeInput.
  if code is "".
    show a toast saying "Type your answer first!".
    return.
  end if.
  add 1 to attempts.
  let code_lower be code in lowercase.
  let passed be check_answer with code_lower.

  if passed is yes.
    let pts be get_points with current_level.
    add pts to total_score.
    let badge be get_badge with current_level.
    if badges_earned is "".
      set badges_earned to badge.
    else.
      set badges_earned to badges_earned joined with ", " joined with badge.
    end if.
    set the text of scoreLabel to "Score: {total_score}".
    set the text of resultLabel to "Correct! You earned {pts} points and the badge: {badge}".
    set the text of feedbackLabel to "Well done! Press Next Level to continue.".
    set the text of badgeLabel to "Badges: {badges_earned}".
    show a toast saying "Level {current_level} complete! Plus {pts} points.".
  else.
    subtract 1 from lives.
    let lives_text be "Lives: {lives}".
    set the text of livesLabel to lives_text.
    if lives is 0.
      set the text of resultLabel to "Out of lives! Here is an example to study:".
      let example be get_example with current_level.
      set the text of exampleLabel to "Example: {example}".
      set lives to 3.
      set the text of livesLabel to "Lives: 3".
      show a toast saying "Lives restored. Study the example and try again.".
    else.
      set the text of resultLabel to "Not quite! {lives} lives remaining.".
      if attempts is at least 3.
        let hint be get_hint with current_level.
        set the text of hintLabel to "Auto hint: {hint}".
      end if.
    end if.
  end if.
end define.

define nextLevel.
  if game_started is no.
    show a toast saying "Start the quest first!".
    return.
  end if.
  if current_level is total_levels.
    set the text of resultLabel to "You are a Quill Master! Final score: {total_score}".
    set the text of feedbackLabel to "You have mastered the Quill programming language!".
    set progress of questProgress to 100.
    set the text of progressLabel to "Progress: 100%".
    show a toast saying "Quest complete! Score: {total_score}".
    return.
  end if.
  add 1 to current_level.
  update_display.
  show a toast saying "Level {current_level} unlocked!".
end define.

show window.
