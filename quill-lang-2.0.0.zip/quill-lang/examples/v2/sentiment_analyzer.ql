note Sentiment Analyzer — AI-style text classification.

define analyze taking text.
  let t be text in lowercase.
  let pos be 0.
  let neg be 0.

  if t contains "great". add 1 to pos. end if.
  if t contains "amazing". add 1 to pos. end if.
  if t contains "excellent". add 1 to pos. end if.
  if t contains "wonderful". add 1 to pos. end if.
  if t contains "fantastic". add 1 to pos. end if.
  if t contains "love". add 1 to pos. end if.
  if t contains "best". add 1 to pos. end if.
  if t contains "good". add 1 to pos. end if.
  if t contains "happy". add 1 to pos. end if.
  if t contains "brilliant". add 1 to pos. end if.
  if t contains "outstanding". add 1 to pos. end if.
  if t contains "awesome". add 1 to pos. end if.

  if t contains "terrible". add 1 to neg. end if.
  if t contains "awful". add 1 to neg. end if.
  if t contains "horrible". add 1 to neg. end if.
  if t contains "hate". add 1 to neg. end if.
  if t contains "worst". add 1 to neg. end if.
  if t contains "bad". add 1 to neg. end if.
  if t contains "poor". add 1 to neg. end if.
  if t contains "disappointing". add 1 to neg. end if.
  if t contains "broken". add 1 to neg. end if.
  if t contains "useless". add 1 to neg. end if.
  if t contains "failed". add 1 to neg. end if.
  if t contains "slow". add 1 to neg. end if.

  if pos is greater than neg.
    return "POSITIVE 😊".
  else if neg is greater than pos.
    return "NEGATIVE 😞".
  else.
    return "NEUTRAL 😐".
  end if.
end define.

say "══════════════════════════════════════".
say "  AI Sentiment Analyzer — Quill 2.0".
say "══════════════════════════════════════".
say "".

let t1 be analyze with "This product is absolutely amazing and wonderful!".
let t2 be analyze with "Terrible experience, broken and awful service.".
let t3 be analyze with "The package arrived on time.".
let t4 be analyze with "Outstanding quality, I love this fantastic tool!".
let t5 be analyze with "Poor performance, very disappointing and slow.".

say "{t1}  |  This product is absolutely amazing and wonderful!".
say "{t2}  |  Terrible experience, broken and awful service.".
say "{t3}  |  The package arrived on time.".
say "{t4}  |  Outstanding quality, I love this fantastic tool!".
say "{t5}  |  Poor performance, very disappointing and slow.".
say "".
say "Enter your own text to analyze!".
ask "Text:" into userText.
let result be analyze with userText.
say "Result: {result}".
