note GitHub Repository Stats — live API data.

say "GitHub Repository Lookup".
say "".
ask "Enter username/repo (e.g. torvalds/linux):" into repo.

let url be "https://api.github.com/repos/" joined with repo.
say "Fetching {repo}...".
say "".

try.
  let response be get url.
  let data be parse response as json.

  let repo_name be data at "full_name".
  let stars be data at "stargazers_count".
  let forks be data at "forks_count".
  let language be data at "language".
  let issues be data at "open_issues_count".
  let description be data at "description".

  say "Repository : {repo_name}".
  say "Stars      : {stars}".
  say "Forks      : {forks}".
  say "Language   : {language}".
  say "Open issues: {issues}".
  say "Description: {description}".
catch err.
  say "Could not fetch: {err}".
  say "Check the format: username/reponame".
end try.
