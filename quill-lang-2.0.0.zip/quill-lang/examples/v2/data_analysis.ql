note Data Analysis — Student Grade Report.

let names be a list of "Alice", "Bob", "Carol", "David", "Eve", "Frank", "Grace", "Henry".
let grades be a list of 92, 78, 95, 65, 88, 72, 98, 55.
let subjects be a list of "Math", "Science", "Math", "History", "Science", "Math", "Science", "History".

let count be the size of names.
let total be the sum of grades.
let avg be total divided by count.
let highest be the maximum of grades.
let lowest be the minimum of grades.

say "═══════════════════════════════".
say "  Student Grade Analysis".
say "═══════════════════════════════".
say "  Students : {count}".
say "  Average  : {avg}".
say "  Highest  : {highest}".
say "  Lowest   : {lowest}".
say "".

say "  All students:".
let i be 0.
for each name in names.
  add 1 to i.
  let g be the item i of grades.
  let s be the item i of subjects.
  let letter be "F".
  if g is at least 90. set letter to "A". end if.
  if g is at least 80 and g is less than 90. set letter to "B". end if.
  if g is at least 70 and g is less than 80. set letter to "C". end if.
  if g is at least 60 and g is less than 70. set letter to "D". end if.
  say "  {name}: {g} ({letter}) — {s}".
end for.

say "".
say "  Top performers (A grade):".
let j be 0.
for each name in names.
  add 1 to j.
  let g be the item j of grades.
  if g is at least 90.
    say "  star {name}: {g}".
  end if.
end for.
