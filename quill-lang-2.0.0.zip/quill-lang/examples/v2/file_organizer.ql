note File Organizer — categorize files by extension.

use files.

say "═══════════════════════════════".
say "  File Organizer Script".
say "═══════════════════════════════".
say "".

let image_exts be a list of "jpg", "jpeg", "png", "gif", "bmp", "svg", "webp".
let doc_exts be a list of "pdf", "doc", "docx", "txt", "md", "rtf".
let video_exts be a list of "mp4", "mov", "avi", "mkv", "wmv".
let audio_exts be a list of "mp3", "wav", "flac", "aac", "ogg".
let code_exts be a list of "py", "js", "ts", "html", "css", "ql", "java".
let data_exts be a list of "csv", "json", "xml", "sql", "xlsx".

say "File categories:".
say "  Images: {the size of image_exts} formats".
say "  Docs:   {the size of doc_exts} formats".
say "  Video:  {the size of video_exts} formats".
say "  Audio:  {the size of audio_exts} formats".
say "  Code:   {the size of code_exts} formats".
say "  Data:   {the size of data_exts} formats".
say "".

ask "Enter a filename (e.g. report.pdf):" into filename.

let parts be filename split by ".".
let n be the size of parts.
let file_ext be the last item in parts.
set file_ext to file_ext in lowercase.

let category be "Unknown".
if image_exts contains file_ext. set category to "Images". end if.
if doc_exts contains file_ext. set category to "Documents". end if.
if video_exts contains file_ext. set category to "Videos". end if.
if audio_exts contains file_ext. set category to "Audio". end if.
if code_exts contains file_ext. set category to "Code". end if.
if data_exts contains file_ext. set category to "Data". end if.

say "".
say "File     : {filename}".
say "Extension: .{file_ext}".
say "Category : {category}".
