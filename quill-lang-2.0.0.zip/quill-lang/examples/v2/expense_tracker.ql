note Expense Tracker — GUI app with live pie chart.

use gui.

set theme to "dark".
open a window titled "Personal Expense Tracker" with width 700, height 580.

create a label named appTitle saying "Personal Expense Tracker".
create a label named totalLabel saying "Total Spent: $0.00".

create a text input named descInput with placeholder "Description".
create a text input named amountInput with placeholder "Amount ($)".
create a button named addBtn saying "Add Expense" that calls addExpense.

create a table named expenseTable with columns "Description", "Amount".
create a pie chart named spendingChart titled "Spending Breakdown".

let total be 0.
let labels be an empty list.
let values be an empty list.

define addExpense.
  let desc be the value of descInput.
  let amtStr be the value of amountInput.

  if desc is "" or amtStr is "".
    show a toast saying "Fill in both description and amount.".
    return.
  end if.

  let amt be 10.
  try.
    set amt to amtStr.
  catch e.
    show a toast saying "Please enter a valid number for amount.".
    return.
  end try.

  add amt to total.
  add desc to labels.
  add amt to values.

  set the text of totalLabel to "Total Spent: $" joined with total.
  add row desc, "$" joined with amt to expenseTable.
  set data of spendingChart to labels, values.
end define.

show window.
