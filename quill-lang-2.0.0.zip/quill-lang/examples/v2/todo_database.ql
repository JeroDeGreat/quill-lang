note To-Do App with SQLite database.

connect to database "todos.db" as db.
execute "CREATE TABLE IF NOT EXISTS todos (id INTEGER PRIMARY KEY AUTOINCREMENT, task TEXT NOT NULL, done INTEGER DEFAULT 0)" on db.

say "To-Do List with SQLite".
say "Commands: add, list, done, delete, quit".
say "".

let running be yes.

while running is yes.
  ask "Command:" into cmd.

  if cmd is "add".
    ask "Task:" into task.
    execute "INSERT INTO todos (task) VALUES (?)" on db with a list of task.
    say "Added: {task}".

  else if cmd is "list".
    let todos be query db with "SELECT id, task, done FROM todos ORDER BY id".
    let count be the size of todos.
    if count is 0.
      say "No tasks yet.".
    else.
      say "".
      for each todo in todos.
        let todo_id be todo at "id".
        let todo_task be todo at "task".
        let todo_done be todo at "done".
        let mark be "[ ]".
        if todo_done is 1.
          set mark to "[x]".
        end if.
        say "  {todo_id}. {mark} {todo_task}".
      end for.
      say "".
    end if.

  else if cmd is "done".
    ask "Task ID:" into tid as number.
    execute "UPDATE todos SET done=1 WHERE id=?" on db with a list of tid.
    say "Marked done!".

  else if cmd is "delete".
    ask "Task ID:" into tid as number.
    execute "DELETE FROM todos WHERE id=?" on db with a list of tid.
    say "Deleted.".

  else if cmd is "quit".
    set running to no.
    say "Goodbye!".

  else.
    say "Unknown command.".
  end if.
end while.
