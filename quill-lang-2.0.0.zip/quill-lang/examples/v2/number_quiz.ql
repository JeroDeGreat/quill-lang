note ═══════════════════════════════════════
note  Math Quiz Game
note  Tests arithmetic skills with scoring
note ═══════════════════════════════════════

use random.

say "".
say "╔═══════════════════════════════╗".
say "║      QUILL MATH QUIZ 🎯      ║".
say "╚═══════════════════════════════╝".
say "".

ask "How many questions? (5-20):" into total as number.
say "".

let score be 0.
let question be 0.

while question is less than total.
  add 1 to question.

  let a be random number between 1 and 12.
  let b be random number between 1 and 12.
  let op be random number between 1 and 4.

  let correct be 0.
  let question_text be "".

  if op is 1.
    set correct to a plus b.
    set question_text to "{a} + {b}".
  else if op is 2.
    if a is less than b.
      let temp be a.
      set a to b.
      set b to temp.
    end if.
    set correct to a minus b.
    set question_text to "{a} - {b}".
  else if op is 3.
    set correct to a times b.
    set question_text to "{a} × {b}".
  else.
    set correct to a.
    let product be a times b.
    set question_text to "{product} ÷ {b}".
  end if.

  say "Question {question}/{total}: {question_text} = ?".
  ask "Your answer:" into answer as number.

  if answer is correct.
    say "✓ Correct! +10 points".
    add 10 to score.
  else.
    say "✗ Wrong. The answer was {correct}.".
  end if.
  say "".
end while.

let max_score be total times 10.
let percentage be score times 100 divided by max_score.

say "═══════════════════════════════".
say "  FINAL SCORE: {score}/{max_score} ({percentage}%)".

if percentage is at least 90.
  say "  🏆 Outstanding!".
else if percentage is at least 70.
  say "  🥈 Well done!".
else if percentage is at least 50.
  say "  🥉 Keep practicing!".
else.
  say "  📚 Study harder!".
end if.
say "═══════════════════════════════".
