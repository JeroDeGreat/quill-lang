note Sales Dashboard — Professional GUI with charts and tables.

use gui.

set theme to "dark".
open a window titled "Sales Dashboard 2024" with width 860, height 620.

create a label named titleLabel saying "Sales Dashboard — Q4 2024".
create a label named subtitleLabel saying "Real-time performance overview".

create a bar chart named revenueChart titled "Monthly Revenue ($000s)".
let months be a list of "Jan", "Feb", "Mar", "Apr", "May", "Jun".
let revenue be a list of 85, 92, 78, 105, 118, 142.
set data of revenueChart to months, revenue.

create a line chart named ordersChart titled "Weekly Order Volume".
let weeks be a list of "Wk1", "Wk2", "Wk3", "Wk4", "Wk5", "Wk6".
let orders be a list of 180, 210, 195, 240, 285, 310.
set data of ordersChart to weeks, orders.

create a table named productsTable with columns "Product", "Units", "Revenue", "Growth".
add row "Pro Widget X", 342, "$51,300", "+34%" to productsTable.
add row "Smart Gadget Y", 285, "$42,750", "+28%" to productsTable.
add row "Ultra Device Z", 197, "$29,550", "+19%" to productsTable.
add row "Basic Tool A", 460, "$18,900", "+8%" to productsTable.

create a label named targetLabel saying "Quarterly Targets:".
create a progress bar named salesProgress.
create a progress bar named customerProgress.

show window.
