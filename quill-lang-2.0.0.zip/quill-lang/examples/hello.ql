note The classic Hello World program in Quill.

say "Hello, World!".
