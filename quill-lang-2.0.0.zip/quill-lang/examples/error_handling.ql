note Error handling with try/catch.

define safe-divide taking a, b.
  if b is 0.
    raise error "Cannot divide {a} by zero.".
  end if.
  return a divided by b.
end define.

try.
  let result be safe-divide with 10, 2.
  say "10 divided by 2 is {result}.".
catch err.
  say "Error: {err}".
end try.

try.
  let result be safe-divide with 5, 0.
  say "This should not print.".
catch err.
  say "Caught an error: {err}".
end try.

say "Program continues after error handling.".
