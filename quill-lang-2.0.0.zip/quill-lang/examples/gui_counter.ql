note A simple GUI counter application.

use gui.

let count be 0.

open a window titled "Quill Counter" with width 320, height 220.

create a label named countLabel saying "Count: 0".
create a button named plusButton saying "Add 1" that calls addOne.
create a button named minusButton saying "Subtract 1" that calls subtractOne.
create a button named resetButton saying "Reset" that calls resetCount.

place countLabel in window.
place plusButton in window.
place minusButton in window.
place resetButton in window.

define addOne.
  add 1 to count.
  set the text of countLabel to "Count: {count}".
end define.

define subtractOne.
  subtract 1 from count.
  set the text of countLabel to "Count: {count}".
end define.

define resetCount.
  set count to 0.
  set the text of countLabel to "Count: 0".
end define.

show window.
