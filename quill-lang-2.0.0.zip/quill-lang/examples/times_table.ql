note Print a times table for any number.

ask "Which times table would you like?" into n as number.

say "".
say "Times table for {n}:".
say "".

repeat from 1 to 12.
  let result be n times the current count.
  say "  {n} x {the current count} = {result}".
end repeat.
