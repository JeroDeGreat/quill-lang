note Object-oriented programming with Quill classes.

define class Animal.
  it has name, sound, legs.

  define create taking name, sound, legs.
    set its name to name.
    set its sound to sound.
    set its legs to legs.
  end define.

  define speak.
    say "{its name} says {its sound}!".
  end define.

  define describe.
    say "{its name} has {its legs} legs.".
  end define.
end class.

define class Dog extending Animal.
  it has name, sound, legs.

  define create taking name.
    set its name to name.
    set its sound to "Woof".
    set its legs to 4.
  end define.

  define fetch.
    say "{its name} fetches the ball!".
  end define.
end class.

let cat be a new Animal with "Whiskers", "Meow", 4.
let bird be a new Animal with "Tweety", "Tweet", 2.
let dog be a new Dog with "Rex".

call speak on cat.
call speak on bird.
call speak on dog.
call describe on cat.
call fetch on dog.
